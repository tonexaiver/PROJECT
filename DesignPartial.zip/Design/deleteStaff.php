<?php

$id=$_GET['id'];
	$con=mysqli_connect('localhost','root','','adweb');
	//create query

	$query = "delete from staff where StaffID=".$id;

	//execute query

	if (mysqli_query($con, $query)) {
		echo "<script>alert('User Successfully Deleted!');window.location.href='allrecords.php'</script>";
	}
	else
	{
		echo "<script>alert('Deletion unsuccessful!!');window.location.href='allrecords.php'</script>";
	}

?>
