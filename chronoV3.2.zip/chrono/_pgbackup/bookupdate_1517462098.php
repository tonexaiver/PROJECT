<?php

$bookid=$_GET['bi'];

$con=mysqli_connect('localhost','root','','samples');

$query = "select * from info where id=".$id;

$result = mysqli_query($con, $query);

$row = mysqli_fetch_array($result);

if(isset($_POST['btnUpdate']))
{
    $con2=mysqli_connect('localhost','root','','dataneil');
    $fn = $_POST["fn"];
    $un = $_POST['un'];
    $ps = $_POST['ps'];
    //create query
    $query= "UPDATE tableneil SET fullname='$fn',username='$un',password='$ps'WHERE id='".$id."';";
    //execute query
    if(mysqli_query($con2,$query))
    {
        //create messagebox for displaying successfully update!
        echo "<script>alert('Successfully Updated...');window.location.href='home.php';</script>";
    }
    else
    {
        
        //create messagebox for displaying failed is updating!
        echo "<script>alert('Update Failed.!!');window.location.href='home.php';</script>";
    }
    
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Starter Template for Bootstrap</title>
        <!-- Bootstrap core CSS -->
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="starter-template.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    </head>
    <body class="bg-info">
        <div class="container">
            <nav class="navbar navbar-inverse">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#" id="home1">Home</a>
                    </div>
                    <div id="navbar" class="collapse navbar-collapse text-primary">
                        <ul class="nav navbar-nav">
                            <li class="active">
                                <a href="manage.php">Manage</a>
                            </li>
                            <li>
                                <a href="#about">Report</a>
                            </li>
                            <li>
                                <a href="home.php">Profile</a>
                            </li>
                            <li>
                                <a href="logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </nav>
            <div class="container">
</div>
            <div class="row"></div>
        </div>
        <div class="container">
            <form role="form clear-fix"> 
                <div class="form-group"> 
                    <label class="control-label">Email address</label>                     
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email"> 
                </div>
                <div class="form-group"> 
                    <label class="control-label">Email address</label>                     
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email"> 
                </div>
                <div class="form-group"> 
                    <label class="control-label">Email address</label>                     
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email"> 
                </div>
                <div class="form-group"> 
                    <label class="control-label">Email address</label>                     
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email"> 
                </div>
                <div class="form-group"> 
                    <label class="control-label">Email address</label>                     
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email"> 
                </div>                 
                <button type="submit" class="btn btn-warning clear-fix btn-lg text-primary">Update</button>                 
            </form>
        </div>
        <!-- /.container -->
        <!-- Bootstrap core JavaScript
    ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
    </body>
</html>
