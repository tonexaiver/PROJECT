-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2018 at 07:54 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fmsg9`
--

-- --------------------------------------------------------

--
-- Table structure for table `ctransaction`
--

CREATE TABLE `ctransaction` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `orno` int(11) NOT NULL,
  `barangay` varchar(100) NOT NULL,
  `barangayad` varchar(100) NOT NULL,
  `dates` varchar(20) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ctransaction`
--

INSERT INTO `ctransaction` (`id`, `fullname`, `purpose`, `orno`, `barangay`, `barangayad`, `dates`, `amount`) VALUES
(1, 'asdasd', 'Fencing', 50, 'asd', 'asd', '(05-25-2018) ', 30),
(2, 'thundershock', 'H2O Connection', 500, 'snake1', 'snake21', '(05-25-2018) ', 30),
(3, 'snake snake snake', 'Electrical', 5992221, 'dulho ', 'PLDT tabunok', '(05-25-2018) ', 30),
(4, 'snake juan snake', 'Fencing', 5000, 'tanke', 'dulho pldt lopez carbon', '(05-25-2018) ', 30),
(5, 'prince', 'Fencing', 123123, 'ward 4', '12321', '(05-28-2018) ', 30),
(6, 'prince', 'Fencing', 1232132, 'barangay', 'ward 4', '(05-29-2018) ', 30),
(7, 'prince', 'Fencing', 1232132, 'barangay', 'ward 4', '(05-29-2018) ', 30);

-- --------------------------------------------------------

--
-- Table structure for table `tblcertification`
--

CREATE TABLE `tblcertification` (
  `ID` int(11) NOT NULL,
  `Fullname` varchar(50) NOT NULL,
  `Age` int(11) NOT NULL,
  `Purok` varchar(50) NOT NULL,
  `Day` int(11) NOT NULL,
  `Month` varchar(50) NOT NULL,
  `Year` int(11) NOT NULL,
  `Purpose` varchar(50) NOT NULL,
  `Amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `ID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Usertype` varchar(50) NOT NULL,
  `RecoveryPass` varchar(50) NOT NULL,
  `DateAdded` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`ID`, `Username`, `Password`, `Usertype`, `RecoveryPass`, `DateAdded`) VALUES
(6, 'prince', '123', 'Admin', '123', '2018-05-24'),
(7, 'larosa', '123', 'Staff', '123', '2018-05-24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ctransaction`
--
ALTER TABLE `ctransaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcertification`
--
ALTER TABLE `tblcertification`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ctransaction`
--
ALTER TABLE `ctransaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblcertification`
--
ALTER TABLE `tblcertification`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
