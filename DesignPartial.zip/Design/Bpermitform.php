<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="mdl/material.min.css">
    <link rel="stylesheet" type="text/css" href="dataTables/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/mdb/compiled.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/style1.css">

</head>
<style type="text/css">
    @media screen{
      #printArea{
        display: none;
      }
    }
    @media print{
      #printArea{
        display: block;
      }
      #btnprint1, #btnprint2{
        display: none;
    }
    
</style>
<body>

    <div id="prinArea">
    <center>
        <img src="image/headerx.jpg" style="width: auto;height: auto; position: center"><br><br><br>
    </center>

    <center><h1><U>BARANGAY CLEARANCE</U> <br><p>(For New/Renewal of business Permit)</p></h1></center><br><br><br><br>
    <center>
        <h4> This is to certify that <u> <?php echo $_POST['fullname']; ?></u>  Filipino, of legal age , is <br> Applying for a BUSINESS PERMIT within the jurisdiction of Poblacion Ward 4</h4>
        <br><br>
        <h4><u><?php echo $_POST['type']; ?></u> <br> Type or Name of Business</h4><br>
        <h4><b>CLEARANCE</b> is hereby issued for issuance of the Municipal Mayor's Permit.</h4><br>
        <h4>Issued on<u><?php echo $_POST['dates']; ?></u>  per O.R No.<u><?php echo $_POST['orno'];?></u>  in the amount of Php <u><?php echo $_POST['amount']; ?> </u></h4>
        
        
        <br><br>
        <img src="image/foots1.jpg" style="width: auto;height: auto; position: center">

    </center>
    </div>
    <center>
    <a href="Bpermitshow.php" id="btnprint2" style="color:white;"><button  class="btn btn-orange">Back</button></a>
    <button type="button" id="btnprint1" class="btn btn-primary" onclick="print()">Print</button>
    </center>
    


</body>
</html>



    