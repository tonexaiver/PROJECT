<?php 
if(isset($_POST['btnUpdate']))
{
	$con2=mysqli_connect('localhost','root','','adweb');

	$id = $_POST["id"];
	$dateposted = $_POST["Dateposted"];
	$lastname = $_POST["lastname"];
	$firstname = $_POST["firstname"];

	$adrs = $_POST["address"];
	$position = $_POST["position"];

	$bdate = $_POST["birthdate"];
	
	//create query
	$query= "UPDATE staff SET lastname='$lastname', firstname='$firstname', address='$adrs', birthdate='$birthdate', position='$position', dateposted='$dateposted' WHERE StaffID='".$id."';";
	//execute query
	if(mysqli_query($con2,$query))
	{
		//create messagebox for displaying successfully update!
		echo "<script>alert('Successfully Updated!');window.location.href='STAFF.php';</script>";
	}
	else
	{
		echo "<script>alert('Successfully Not Updated!');window.location.href='STAFF.php';</script>";

	}
	
}
?>