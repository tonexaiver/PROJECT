<?php include 'header4staff.php'; ?>
<?php 
$con = mysqli_connect('localhost','root','','fmsg9');
$query = "select * from tblcertification;";
$result = mysqli_query($con,$query);

?>
<main>
	<section class="card card-cascade narrower">
		<div class="row">
			<div class="col-md-12" style=" height: auto;">
				<div class="view py-3 card-header info-color white-text" style="background-color: #3f5c80 ; font-family: Century Gothic ; font-size: 20px; text-align: left">
                    <div class="row">
                        <div class="col-md-8">
                            <i class="fa fa-folder-open"></i>
                    		SHOW LIST
                   
                        </div>
                        <div class="col-md-4">
                            <a href="CertificationUI.php" class="btn-floating btn-small blue" style="float: right" ripple-radius><i class="fa fa-backward"></i></a>
                         </div>
                    </div>
                </div>
                <div class="card-body">
                	<div class="row">
                		<div class="col-md-12">
                			<form>
                				<div class="card">
								    <div class="card-body">

								        <!--Table-->
								        <table class="table ">

								            <!--Table head-->
								            
								                <tr>
								                    <th>ID</th>
								                    <th>fullname</th>
								                    <th>age</th>
								                    <th>purok</th>
								                    <th>day</th>
								                    <th>month</th>
								                    <th>year</th>
								                    <th>purpose</th>
								                    <th>amount</th>
								                    <th></th>
								                </tr>
								         
								            <!--Table head-->

								            <!--Table body-->
								          
								                <tr>
								                    <?php 
								                    	while ($row = mysqli_fetch_array($result)) {
								                    		echo "<tr>";
								                    		echo "<td>".$row['ID']."</td>";
								                    		echo "<td>".$row['Fullname']."</td>";
								                    		echo "<td>".$row['Age']."</td>";
								                    		echo "<td>".$row['Purok']."</td>";
								                    		echo "<td>".$row['Day']."</td>";
								                    		echo "<td>".$row['Month']."</td>";
								                    		echo "<td>".$row['Year']."</td>";
								                    		echo "<td>".$row['Purpose']."</td>";
								                    		echo "<td>".$row['Amount']."</td>";
								                    		echo "<td><a href='Certificatesprint.php?id=".$row['ID']."&action=edit'><u>Go To</u></td>";
								                    		echo "</tr>";
								                    	}



								                     ?>
								                </tr>
								           
								            <!--Table body-->

								        </table>
								        <!--Table-->

								    </div>
								</div>
                			</form>
                		</div>
                	</div>
                </div>
			</div>
			
		</div>
	</section>
</main>
<?php include 'footer.php';?>