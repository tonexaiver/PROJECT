<?php

$id=$_GET['id'];
	$con=mysqli_connect('localhost','root','','adweb');
	//create query
	$query = "delete from tblresidents where ResidentsID=".$id;


	//execute query
	if(mysqli_query($con, $query))
	{
		echo "<script>alert('User Successfully Deleted!');window.location.href='RESIDENTS.php'</script>";
	}
	else
	{
		echo "<script>alert('Deletion unsuccessful!!');window.location.href='RESIDENTS.php'</script>";
	}


?>
