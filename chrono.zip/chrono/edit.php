<?php

$id=$_GET['id'];

$con=mysqli_connect('localhost','root','','library_system');

$query = "select * from tableneil where id=".$id;

$result = mysqli_query($con, $query);

$row = mysqli_fetch_array($result);

if(isset($_POST['btnUpdate']))
{
	$con2=mysqli_connect('localhost','root','','library_system');
	$fn = $_POST["fn"];
	$un = $_POST['un'];
	$ps = $_POST['ps'];
	//create query
	$query= "UPDATE tableneil SET fullname='$fn',username='$un',password='$ps'WHERE id='".$id."';";
	//execute query
	if(mysqli_query($con2,$query))
	{
		//create messagebox for displaying successfully update!
		echo "<script>alert('Successfully Updated');window.location.href='home.php';</script>";
	}
	else
	{
		
		//create messagebox for displaying failed is updating!
		echo "<script>alert('Update Failed, Something went wrong!');window.location.href='home.php';</script>";
	}
	
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Update Registration</title>
	<link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css">
	<style type="text/css">
		body{
			background-color: skyblue;

		}


		.card-header{
			background-color: gray; 
		}
		.card-body{
			background-color: ;

		}
		#btnSubmit, #btns{
			border-radius: 100px;	
			text-decoration: none
		}
		b{
			color:black;
		}
		.form-control{
			border-top: none;
			border-right: none;
			border-left: none;
		}
		.card-footer{
			background-color: transparent;
		}


	</style>
	
</head>
<body>
	<div class="container">
			<div class="row">
				<div class="col-md-3"></div>
				<div class="col-md-6"><br>
					<div class="container"><br>
						<div class="card">
							<div class="card-header"><center><h5></h5></center></div>
							<div class="card-body">
								<center>
									<form name="frmedit" action="" method="post">
										Full Name : &nbsp<input type="text" name="fn" value = "<?php echo $row['fullname']; ?>" /><br/><br>
										User Name : <input type="text" name="un" value = "<?php echo $row['username']; ?>" /><br/><br>
										Password : &nbsp&nbsp<input type="text" name="ps" value = "<?php echo $row['password']; ?>" /><br/><br>
										
										<button type="submit" class="btn btn-outline-success btn-block" name="btnUpdate">Update</button>
									</form>
								</center>
							</div>
						</div>
					</div><br>
				</div>
				<div class="col-md-3">
				</div>
			</div>
		</div>
	
</body>
</html>




									


