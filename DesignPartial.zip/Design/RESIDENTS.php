<?php
$con = mysqli_connect('localhost','root','','adweb');
$query2 = "SELECT * FROM tblresidents;";
$result2 = mysqli_query($con,$query2);
?>
<?php include 'headerstaff.php'; ?>
<main>
	<div class="container-fluid">
		<section>
			<div class="row">
			<div class="col-md">
					<h5 class="my-2 h5">REGISTERED RESIDENTS</h5>
                        <form><div class="table-responsive">
        <table id="residentstable" class="stripe hover order-column row-border">
            <thead>
            <tr>
                <th>Residents ID</th>
                <th>Date Posted</th>
                <th>Lastname</th>
                <th>Firstname</th>
                <th>Middlename</th>
                <th>Address</th>
                <th>Civil Status</th>
                <th>Religion</th>
                <th>Birthdate</th>
                <th>ACTION</th>



                
            </tr>
            </thead>

            <tbody>
                <?php 
                while ($row = mysqli_fetch_array($result2)) {
                    
                    echo "<tr>";
                    echo "<td>".$row['ResidentsID']."</td>";
                    echo "<td>".$row['Dateposted']."</td>";
                    echo "<td>".$row['Lastname']."</td>";
                    echo "<td>".$row['Firstname']."</td>";
                    echo "<td>".$row['Middlename']."</td>";
                    echo "<td>".$row['Address']."</td>";
                    echo "<td>".$row['CivilStatus']."</td>";
                    echo "<td>".$row['Religion']."</td>";
                    echo "<td>".$row['Birthdate']."</td>";
                    echo "<td><button class='btn btn-info'><a class='white-text' href='edit.php?id=".$row['ResidentsID']."&action=edit'>EDIT</a></button><button class='btn btn-danger btn-md'><a class='white-text' href='delete.php?id=".$row['ResidentsID']."&action=delete'>DELETE</a></button></td>";

                    echo "</tr>";
                }

                ?>
            </tbody>
        </table>
        </div>
    </form>
                    </div>
			</div>
		</section>
	</div>
</main>
<?php include 'footer.php';?>
