
<?php require 'header4admin.php';?>

   <body  style="background-color: #faffbd; ">
    <!--Main layout-->
    <main style="height: 600px;">

         <div class="row">
             <div class="col-md-4"><a href="finaladminpanel.php" class="btn-floating btn-small blue animated fadeInDownBig" style="float: left" ripple-radius><i class="fa fa-backward"></i></a></div>
             <div class="col-md-4">
              <form class="animated flipInY" method="POST">
                <p class="h4 text-center mb-4 mt-5">EDIT ACCOUNT</p>
                    <!-- Material input email -->
                    <div class="md-form">
                        <div class="row">
                            
                            <div class="col-md-1"><i class="fa fa-user prefix grey-text"></i></div>
                            <div class="col-md-9"><input type="text" id="materialFormLoginEmailEx" class="form-control">
                            <label for="materialFormLoginEmailEx">Username</label></div>
                            <div class="col-md-2">
                                <div class="text-center mt-4">
                                    <button class="btn btn-default" type="submit">EDIT</button>
                                </div>
                            </div>
                        </div>
                        
                        
                        
                        
                    </div>

                    <div class="md-form">
                        <div class="row">
                            <div class="col-md-1"><i class="fa fa-lock prefix grey-text"></i></div>
                            <div class="col-md-9"><label for="materialFormLoginPasswordEx">Change Password</label></div>
                            <div class="col-md-2">
                                <div class="text-center mt-4">
                                    <button class="btn btn-default" type="submit">EDIT</button>
                                </div>
                            </div>

                        </div> 
                    </div>
                    <div class="md-form">
                        <div class="row">
                            <div class="col-md-1"><i class="fa fa-lock prefix grey-text"></i></div>
                            <div class="col-md-9"><label for="materialFormLoginPasswordEx">Change Recovery Password</label></div>
                            <div class="col-md-2">
                                <div class="text-center mt-4">
                                    <button class="btn btn-default" type="submit">EDIT</button>
                                </div>
                            </div>

                        </div> 
                    </div>
                    

                    <div class="text-center mt-4">
                        <button class="btn btn-default" type="submit">SAVE CHANGES</button>
                        <button class="btn btn-default" type="submit">GO BACK</button>
                    </div>
                </form>
             </div>
             <div class="col-md-4"></div>
         </div>



      
    </main>
    <!--Main layout-->
</body>
    

 <?php require 'footer.php';?>  
