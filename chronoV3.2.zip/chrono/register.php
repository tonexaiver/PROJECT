<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css">
	<style type="text/css">
		body{
			background-color: black;

		}


		.card-header{
			background-color: gray; 
		}
		.card-body{
			background-color: ;

		}
		#btnSubmit, #btns{
			border-radius: 100px;	
			text-decoration: none
		}
		b{
			color:black;
		}
		.form-control{
			border-top: none;
			border-right: none;
			border-left: none;
		}
		.card-footer{
			background-color: transparent;
		}


	</style>
	
</head>
<body>
	<div class="container">
			<div class="row">
				<div class="col-md-3"></div>
				<div class="col-md-6"><br>
					<div class="container"><br>
						<div class="card">
							<div class="card-header"><center><h5>Registration Form</h5></center></div>
							<div class="card-body">
								<form action="add.php" method="POST">
									<center>
										Full name : &nbsp<input type="text" name="fn"><br><br>
										Username :&nbsp&nbsp<input type="text" name="un"><br><br>
										Password :&nbsp&nbsp <input type="Password" name="ps"><br><br>

									<button  type="submit" name="submit" id="btnSubmit" class="btn btn-outline-success btn-block"><h5>ADD</h5></button>
									
									</center>
									
									
								</form>
														
								
							</div>
						</div>
					</div><br>
				</div>
				<div class="col-md-3">
				</div>
			</div>
		</div>



	

</body>
</html>