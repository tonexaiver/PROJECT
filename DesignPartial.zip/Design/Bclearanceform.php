<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="mdl/material.min.css">
    <link rel="stylesheet" type="text/css" href="dataTables/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/mdb/compiled.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/style1.css">

</head>
<style type="text/css">
    @media screen{
      #printArea{
        display: none;
      }
    }
    @media print{
      #printArea{
        display: block;
      }
      #btnprint1, #btnprint2{
        display: none;
    }
    
</style>
<body>

    <div id="prinArea">
    <center>
        <img src="image/headerx.jpg" style="width: auto;height: auto; position: center"><br><br><br>
    </center>

    <center><h1>BARANGAY CLEARANCE</h1></center><br><br><br><br>
    <center>
        <h4>Clearance for : <u> <?php echo $_POST['ddb']; ?></u></h4>
        <h4>Is approved in favor of <u><?php echo $_POST['fullname']; ?></u> of </h4>
        <h4>legal age, and a resident of <u><?php echo $_POST['barangay']; ?></u> at </h4>
        <h4>the site and location at <u><?php echo $_POST['barangayad']; ?></u>.</h4>
        <h4><b>ISSUED</b> upon his/her request and paid per O.R. No. <u><?php echo $_POST['orno']; ?></u> dated </h4>
        <h4><u><?php echo $_POST['dates']; ?></u> in the amount of Php. <u><?php echo $_POST['amount']; ?>.00</u></h4>
        <br><br>
        <img src="image/foots1.jpg" style="width: auto;height: auto; position: center">

    </center>
    </div>
    <center>
    <a href="Bclearanceshow.php" id="btnprint2" style="color:white;"><button  class="btn btn-orange">Back</button></a>
    <button type="button" id="btnprint1" class="btn btn-primary" onclick="print()">Print</button>
    </center>
    


</body>
</html>



    