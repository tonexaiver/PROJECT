<?php 
$fullname=$_POST['fullname'];
$age=$_POST['age'];
$purok=$_POST['purok'];
$day=$_POST['day'];
$month=$_POST['month'];
$year=$_POST['year'];
$purpose=$_POST['purpose'];
$amount=$_POST['amount'];




	$con =mysqli_connect('localhost','root','','fmsg9');
	$query = "INSERT INTO tblcertification (fullname,age,purok,day,month,year,purpose,amount) VALUES ('$fullname','$age','$purok','$day','$month','$year','$purpose','$amount');";

	if (mysqli_query($con,$query)) {
		
		echo "<script>alert('successfully added');window.location.href='CertificationUI.php';</script>";
	}
	else
		{
			echo "<script>alert('Check your entry for errors!');</script>";
		}





 ?>