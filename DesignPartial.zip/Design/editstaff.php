<?php

$id=$_GET['id'];

$con=mysqli_connect('localhost','root','','adweb');
//create query
$query = "select * from staff where StaffID=".$id;
//execute query, save result to $result variable
$result = mysqli_query($con, $query);

$row = mysqli_fetch_array($result);

?>
<?php include 'headerstaff.php'; ?>
<main>
	<div class="container">
		<section>
			<div class="row">
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<div class="card card-cascade narrower">

        <!--Card image-->
        	<div class="view gradient-card-header purple-gradient">
            	<h4>Update Staff Form</h4>
   
        </div>
        <!--/Card image-->

        <!--Card content-->
        <div class="card-body">
        		<form method="POST" action="updatestaff.php">
        			<div class="md-form form-sm">
                   
                        <input type="hidden" name="id" value = "<?php echo $row['StaffID']; ?>">
                        </div>
                
                <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form29" class="form-control" name="lastname" value = "<?php echo $row['lastname']; ?>">
                        <label for="form29">Lastname</label>
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="firstname" value = "<?php echo $row['firstname']; ?>">
                        <label for="form30">Firstname</label>
                    </div>
                     <div class="md-form form-sm">
                        <i class="fa fa-address-book prefix"></i>
                        <input type="text" id="form31" class="form-control" name="address" value = "<?php echo $row['address']; ?>">
                        <label for="form31">Address</label>
                    </div>
                     <div class="md-form form-sm">
                        <i class="fa fa-calendar prefix"></i>
                        <input type="text" class="form-control datepicker" name="birthdate" value = "<?php echo $row['birthdate']; ?>">
                        <label for="date-picker">Birthdate</label>
                                  
                    </div>
                     <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form33" class="form-control" name="position" value = "<?php echo $row['position']; ?>">
                        <label for="form33">Position</label>
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-calendar prefix"></i>
                        <input type="text" class="form-control datepicker" name="Dateposted" value = "<?php echo $row['dateposted']; ?>">
                        <label for="date-picker">Date</label>
                                  
                    </div>
                  

                   
                    
    
                    <div class="text-center mt-2">
                        <button class="btn btn-teal" type="submit" name="btnUpdate">UPDATE<i class="fa fa-sign-in ml-1"></i></button>
                    </div>
    
                </div>
                </form>
           

        </div>
        <!--/.Card content-->

    </div>
</div>
					
		
	<div class="col-md-2"></div>
			</div>
		</section>
	</div>
</main>
	
<?php include 'footer.php';?>



