
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="mdl/material.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/mdb/compiled.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/style1.css">
</head>
    <style type="text/css">
        body,html{
            background:url(image/img.jpg);
            background-size: cover;
            background-attachment: fixed;

        }
        .card {
            background-color: rgba(229, 228, 255, 0.2);
        }
       
    </style>
<body>
<main>
    <section>
    <div class="container">
        <div class="row">
            <div class="col-md-7" style="margin-top: 5em"><img src="image/officiallogo.png" class="mx-auto d-block animated flipInY image-responsive" style=" height: 90%; width: 80%;"></div>
            <div class="col-md-4 mb-r animated fadeInRight" style="margin-top: 12em;" id="login">
                
<div class="card " style="background-color: #faffbd;">
<div class="card-body">
<form action="forgotPasscode.php" method="post">
    <p class="h4 text-center mb-4">Forgot Password</p>

   
    <div class="md-form">
        <i class="fa fa-lock prefix grey-text"></i>
        <input type="password" id="pass1" class="form-control" name="recpass">
        <label for="pass1">Recovery Password</label>
    </div>

    <div class="md-form">
        <i class="fa fa-lock prefix grey-text"></i>
        <input type="password" id="pass2" class="form-control" name="newpass">
        <label for="pass2">New Password</label>
    </div>
    <div class="md-form">
        <i class="fa fa-lock prefix grey-text"></i>
        <input type="password" id="pass3" class="form-control" name="newconpass">
        <label for="pass3">Confirm Password</label>
    </div>
  

    <div class="text-center mt-4">
        <button class="btn btn-default"> <a href="logini.php" style="color: white">Back</a></button>
        <button class="btn btn-default" type="submit">Recover</button>
    </div>

</form>

                      
            </div></div></div>
        </div>
        </div>
    </section>
</main>


 <script type="text/javascript" src="jquery/jquery.js"></script>
<script type="text/javascript" src="popper/popper.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="jquery/mdb.js"></script>
</body>

</html>
