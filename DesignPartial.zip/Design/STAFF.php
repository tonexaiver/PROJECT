<?php
$con = mysqli_connect('localhost','root','','adweb');
$query = "SELECT * FROM staff;";
$result = mysqli_query($con,$query);

?>

<?php require 'header.php';?>
<main>
	<div class="container">
		<section>
			<div class="row">
				<div class="col-md-12">
					<h5 class="my-2 h5 text-center">BARANGGAY STAFF</h5>

                        <form>
                        <div class="table-responsive">
        <table id="stafftable" class="table stripe hover order-column row-border">
            <thead>
            <tr>
                <th>StaffID</th>
                <th>Lastname</th>
                <th>Firstname</th>
                <th>Address</th>
                <th>Birthdate</th>
                <th>Position</th>
                <th>DatePosted</th>
                <th>ACTION</th>
            </tr>
            </thead>

            <tbody>
                <?php 
                while ($row = mysqli_fetch_array($result)) {
                    # code...
                    echo "<tr>";
                    echo "<td>".$row['StaffID']."</td>";
                    echo "<td>".$row['lastname']."</td>";
                    echo "<td>".$row['firstname']."</td>";
                    echo "<td>".$row['address']."</td>";
                    echo "<td>".$row['birthdate']."</td>";
                    echo "<td>".$row['position']."</td>";
                    echo "<td>".$row['dateposted']."</td>";
                    echo "<td><button class='btn btn-info'><a class='white-text' href='Editstaff.php?id=".$row['StaffID']."&action=edit'>EDIT</a></button><button class='btn btn-danger btn-md'><a class='white-text' href='delete.php?id=".$row['StaffID']."&action=delete'>DELETE</a></button></td>";
                    echo "</tr>";
                }

                ?>
            </tbody>
        </table>
        </div>
    </form>
                    </div>
			</div>
		</section>
	</div>
</main>
 <?php require 'footer.php';?>  