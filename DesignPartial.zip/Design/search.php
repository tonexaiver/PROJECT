<?php  
 $connect = mysqli_connect("localhost", "root", "", "adweb");  
 if(isset($_POST["query"]))  
 {  
      $output = '';  
      $query = "SELECT * FROM staff WHERE lastname LIKE '%".$_POST["query"]."%'";  
      $result = mysqli_query($connect, $query);  
      $output = '<ul class="list-unstyled">';  
      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '<li>'.$row["lastname"].", ".$row["firstname"].'</li>';  
           }  
      }  
      else  
      {  
           $output .= '<li>Name not Found</li>';  
      }  
      $output .= '</ul>';  
      echo $output;  
 }  
 ?>  