<?php 
if(isset($_POST['btnLogin']))
{
    $un = $_POST['username'];
    $ps= $_POST['password'];
    $admin="Admin";
    $staff="Staff";

    if (empty($un)|| empty($ps)) {
        echo "<script>alert('field is empty!');location.href='logini.php'</script>";
    }
    else
    {

        $con= mysqli_connect('localhost','root','','fmsg9');
        $query = "SELECT * from tblusers where Username = '$un' AND Password = '$ps'AND Usertype = '$admin'";
        $query1 = "SELECT * from tblusers where Username = '$un' AND Password = '$ps'AND Usertype = '$staff'";
       
        

        $result = mysqli_query($con,$query);
        $result1 = mysqli_query($con,$query1);
        $num_rows = mysqli_num_rows($result);
        $num_rows1 = mysqli_num_rows($result1);
        if ($num_rows1 >0) {
            session_start();
            $_SESSION['username'] = $un;
            echo "<script>location.href='Finalstaffpanel.php'</script>";
            echo '<input type="text" name="user" value='.$row['Username'].'><br/>';
        }
        else if ($num_rows >0) {
            session_start();
            $_SESSION['username'] = $un;
            echo "<script>location.href='FinalAdminPanel.php'</script>";
            echo '<input type="text" name="user" value='.$row['Username'].'><br/>';
        }
        
        else
        {
            echo "<script>alert('Wrong Username/password!!');location.href='logini.php'</script>";
        }
    }
}

?>
