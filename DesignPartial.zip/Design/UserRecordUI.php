
<?php require 'header4admin.php';?>

    <!--Main layout-->
    <main>
      
<!--Section: Table-->
<section class="mb-5">

  

<!--Card-->
<div class="card card-cascade narrower">
<form class="form-inline mt-2 ml-2">
                  
              </form>
    <!--Card header-->
    
<!--Card header-->
<div class="view py-3 gradient-card-header info-color-dark mx-4 d-flex justify-content-between align-items-center">


        <div>
      <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2">
          <i class="fa fa-th-large mt-0"></i>
      </button>
      <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2">
          <i class="fa fa-columns mt-0"></i>
      </button>
  </div>

  <a href="" class="white-text mx-3">USER RECORDS</a>

  <div>
      <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2">
          <i class="fa fa-pencil mt-0"></i>
      </button>
      <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2">
          <i class="fa fa-remove mt-0"></i>
      </button>
      <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2">
          <i class="fa fa-info-circle mt-0"></i>
      </button>
  </div>

    </div>
    <!--/Card header-->

    
<!--Card content-->
<div class="card-body">

  <div class="table-responsive">
<form class="form-inline mt-2 ml-2">
                  <input class="form-control my-0 py-0" type="text" placeholder="Search" style="max-width: 150px;">
                  <button class="btn btn-sm btn-info ml-2 px-2">
                      <i class="fa fa-search"></i>
                  </button>
              </form>
  
        
<table class="table">
    
<thead>
    <tr>
        <th>#</th>
        <th class="th-lg">First column</th>
        <th class="th-lg">Second column</th>
        <th class="th-lg">Third column</th>
        <th class="th-lg">Fourth column</th>
        <th class="th-lg">Fifth column</th>
        <th class="th-lg">Sixth column</th>
    </tr>
</thead>

    <tbody>
        <tr>
            <th scope="row">1</th>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
        </tr>
        <tr>
            <th scope="row">2</th>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
        </tr>
        <tr>
            <th scope="row">3</th>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
            <td>Lorem Ipsum</td>
        </tr>
    </tbody>
                    
</table>
 <hr class="my-0">
<div class="row">
    <!--Bottom Table UI-->

<div class="col-md-8 d-flex justify-content-between">

<!--Name-->
    <select class="mdb-select colorful-select dropdown-primary mt-2 hidden-md-down">
        <option value="" disabled>Rows number</option>
        <option value="1" selected>10 rows</option>
        <option value="2">25 rows</option>
        <option value="3">50 rows</option>
        <option value="4">100 rows</option>
    </select>

</div>
<!--Bottom Table UI-->

<div class="col-md-4">
          <!--Pagination -->
<nav class="mt-4">
    <ul class="pagination pagination-circle pg-blue mb-0">

        <!--First-->
        <li class="page-item disabled">
            <a class="page-link">First</a>
        </li>

        <!--Arrow left-->
        <li class="page-item disabled">
            <a class="page-link" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Previous</span>
            </a>
        </li>

        <!--Numbers-->
        <li class="page-item active">
            <a class="page-link">1</a>
        </li>
        <li class="page-item">
            <a class="page-link">2</a>
        </li>
        <li class="page-item">
            <a class="page-link">3</a>
        </li>
        <li class="page-item">
            <a class="page-link">4</a>
        </li>
        <li class="page-item">
            <a class="page-link">5</a>
        </li>

        <!--Arrow right-->
        <li class="page-item">
            <a class="page-link" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Next</span>
            </a>
        </li>

        <!--First-->
        <li class="page-item">
            <a class="page-link">Last</a>
        </li>

    </ul>
</nav>
<!--/Pagination -->
</div>
</div>
  </div>

</div>
<!--/.Card-->


</section>
<!--Section: Table-->

    </main>
    <!--Main layout-->

    
   
    

 <?php require 'footer.php';?>  
