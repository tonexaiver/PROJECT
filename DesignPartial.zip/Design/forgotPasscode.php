<?php

	$recover=$_POST['recpass'];

	$con1=mysqli_connect('localhost','root','','fmsg9');
	$query1 = "SELECT * from tblusers where RecoveryPass=".$recover;
	
	$newpass=$_POST['newpass'];
	$newconpass=$_POST['newconpass'];

	if (empty($recover)||empty($newpass)||empty($newconpass)) {

		echo "<script>alert('fill out all fields');window.location.href='forgotPassUI.php';</script>";
	}

	else if ($newpass!=$newconpass)
	{
		echo "<script>alert('The password mismatch!');window.location.href='forgotPassUI.php';</script>";
	}
	
	
	else if (mysqli_query($con1,$query1)) {
		$recover=$_POST['recpass'];
		$newpass=$_POST['newpass'];
		$con=mysqli_connect('localhost','root','','fmsg9');
		$query= "UPDATE tblusers SET Password='$newpass' WHERE RecoverPass='".$recover."';";

		if (mysqli_query($con,$query)) {

		echo "<script>alert('successfully changed!');window.location.href='logini.php';</script>";
		}
		else
			{
				echo "<script>alert('Invalid Recovery Password!');window.location.href='forgotPassUI.php';</script>";
			}
	}

	
	
	
	

?>