<?php 
$bi=$_POST['bi'];
$bt=$_POST['bt'];
$bfn=$_POST['bfn'];
$db=$_POST['db'];
$le=$_POST['le'];
	
	if(empty($bt)||empty($bfn)||empty($le)){
		echo "<script>alert('Please Fill out all empty Fields');window.location.href='books.php';</script>"	;
	}
	else
	{
		$con = mysqli_connect('localhost','root','','dataneil');

		$query = "INSERT INTO books(bookid,booktitle,bookname,dates,librarian) VALUES ('$bi','$bt','$bfn','$db','$le');";

		if (mysqli_query($con,$query)){

			echo "<script>alert('Successfully Added');window.location.href='books.php';</script>";
		}
		else
		{
			echo "<script>alert('Registration Errors.!! Check your entry for Errors.!!');</script>";
		}
	}

 ?>