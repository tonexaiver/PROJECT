<?php 
session_start();
if (!isset($_SESSION['username'])) {
    header("location: index.php");
}
$con = mysqli_connect('localhost','root','','dataneil');
$query = "select * from tableneil;";
$result = mysqli_query($con,$query);

?> 
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Dashboard Template for Bootstrap</title>
        <!-- Bootstrap core CSS -->
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="dashboard.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        .modal-dialog {
  width: 750px;
  margin: auto;
}
    </style>
    </head>
    <body>
        <div class="container">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#">Project name</a>
                    </div>
                    <div id="navbar" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="#">Dashboard</a>
                            </li>
                            <li>
                                <a href="#">Settings</a>
                            </li>
                            <li>
                                <a href="#">Profile</a>
                            </li>
                            <li>
                                <a href="#">Logout</a>
                            </li>
                        </ul>
                        <form class="navbar-form navbar-right">
                            <input type="text" class="form-control" placeholder="Search...">
                        </form>
                    </div>
                </div>
            </nav>
            <div class="container-fluid">
                <div class="row"></div>
                <div class="row">
                    <div class="row">
                        <div class="row"></div>
                    </div>
                </div>
            </div>
            <!-- Bootstrap core JavaScript
    ================================================== -->
            <!-- Placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="bootstrap/js/bootstrap.min.js"></script>
            <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
            <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
            <div class="container">
                <form role="form"> 
                    <div class="form-group"> 
                        <label class="control-label" for="exampleInputEmail1">Book ID</label>                         
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder=""> 
                    </div>
                    <div class="form-group"> 
                        <label class="control-label" for="exampleInputEmail1">Book Title</label>                         
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder=""> 
                    </div>
                    <div class="form-group"> 
                        <label class="control-label" for="exampleInputEmail1">Borrower Full Name</label>                         
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder=""> 
                    </div>
                    <div class="form-group"> 
                        <label class="control-label" for="exampleInputEmail1">Date Borrowed</label>                         
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder=""> 
                    </div>
                    <div class="form-group"> 
                        <label class="control-label" for="exampleInputEmail1">Librarian Engarge</label>                         
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder=""> 
                    </div>                     
                </form>
            </div>
            <div class="container text-center clear-fix">
                <button type="button" class="btn btn-default">Add New</button>
                <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal1">View Added</button>
            </div>
            <div class="container">
                <div class="modal fade pg-show-modal" id="modal1" tabindex="-1" role="dialog" aria-hidden="true"> 
                    <div class="modal-dialog"> 
                        <div class="modal-content modal-dialog modal-lg"> 
                            <div class="modal-header"> 
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>                                 
                                <h4 class="modal-title text-center ">Modal title</h4> 
                            </div>                             
                            <div class="modal-body">
                                <table class="table"> 
                                    <thead> 
                                        <tr> 
                                            <th>Book ID</th> 
                                            <th>Book Title</th> 
                                            <th>Borrower Full Name</th> 
                                            <th>Date Borrowed</th> 
                                        </tr>                                         
                                    </thead>                                     
                                    <tbody> 
                                        <tr> 
                                            <td>1</td> 
                                            <td>Mark</td> 
                                            <td>Otto</td> 
                                            <td>@mdo</td> 
                                        </tr>                                         
                                        <tr> 
                                            <td>2</td> 
                                            <td>Jacob</td> 
                                            <td>Thornton</td> 
                                            <td>@fat</td> 
                                        </tr>                                         
                                        <tr> 
                                            <td>3</td> 
                                            <td>Larry</td> 
                                            <td>the Bird</td> 
                                            <td>@twitter</td> 
                                        </tr>                                         
                                    </tbody>
                                </table>                                 
                            </div>                             
                            <div class="modal-footer"> 
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>                                 
                                <button type="button" class="btn btn-primary">Save changes</button>                                 
                            </div>                             
                        </div>                         
                    </div>                     
                </div>
            </div>
    </body>
</html>
