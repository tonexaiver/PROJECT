
<?php require 'header4staff.php';?>
 
 <style type="text/css">
   a {
    color:white;
   }
 </style>
    <!--Main layout-->
    <main>
         <div class="row">
           <div class="col-md-4 bg-black blue-gradient animated fadeInLeft" style="height: 320px; border: 20px solid white;">
            <i class="fa fa-user-circle" aria-hidden="true" style="margin-top: 10px; margin-left: 0; color: white;"></i><h4 style="margin-top: 10%; color: white; text-align: center;"><img src="image/icon1.png" style="height: 100px; width: 100px;"><br><br><a href="CertificationUI.php">Barangay Residency Certificate</a></h4></div>

           <div class="col-md-4 bg-black blue-gradient animated fadeInDown" style="height: 320px; border: 20px solid white;">
            <i class="fa fa-user-circle" aria-hidden="true" style="margin-top: 10px; margin-left: 0; color: white;"></i><h4 style="margin-top: 10%; color: white; text-align: center;"><img src="image/icon2.png" style="height: 100px; width: 100px;"><br><br><a href="BpermitUI.php">Barangay Business Clearance</a></h4></div>

             <div class="col-md-4 bg-black blue-gradient animated fadeInRight" style="height: 320px; border: 20px solid white;">
            <i class="fa fa-user-circle" aria-hidden="true" style="margin-top: 10px; margin-left: 0; color: white;"></i><h4 style="margin-top: 10%; color: white; text-align: center;"><img src="image/icon3.png" style="height: 100px; width: 100px;"><br><br>Certificate of Low Income/ Indigency</h4></div>
        </div>
          <div class="row">
            <div class="col-md-4 bg-black blue-gradient animated rollIn" style="height: 320px; border: 20px solid white;">
            <i class="fa fa-user-circle" aria-hidden="true" style="margin-top: 10px; margin-left: 0; color: white;"></i><h4 style="margin-top: 10%; color: white; text-align: center;"><img src="image/icon4.png" style="height: 100px; width: 100px;"><br><br><a href="bclearanceUI.php">Barangay Construction Clearance </a></h4></div>

             <div class="col-md-4 bg-black blue-gradient animated zoomInUp" style="height: 320px; border: 20px solid white;">
            <i class="fa fa-user-circle" aria-hidden="true" style="margin-top: 10px; margin-left: 0; color: white;"></i><h4 style="margin-top: 10%; color: white; text-align: center;"><img src="image/icon5.png" style="height: 100px; width: 100px;"><br><br>Travel Certification for Livestock</h4></div>

             <div class="col-md-4 bg-black blue-gradient animated rotateInDownRight" style="height: 320px; border: 20px solid white;">
            <i class="fa fa-user-circle" aria-hidden="true" style="margin-top: 10px; margin-left: 0; color: white;"></i><h4 style="margin-top: 10%; color: white; text-align: center;"><img src="image/icon6.png" style="height: 100px; width: 100px;"><br><br>Cutting Certification</h4></div>
        </div>
        
    </main>
    <!--Main layout-->

    
   
    

 <?php require 'footer.php';?>  
