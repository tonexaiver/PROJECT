<?php 

session_start();
if(isset($_SESSION['username'])){
	header("location: home.php");
}

?> 
<!DOCTYPE html> 
<html> 
    <head> 
        <title>Login Page</title>         
        <link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.css"> 
        <link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css"> 
        <style type="text/css"> 
            body{
            background-color: black;
            }
            .card-header{
            background-color: gray; 
            }
            .card-body{
            background-color: ;
            }
            #btnSubmit, #btns{
            border-radius: 100px;	
            text-decoration: none
            }
            b{
            color:black;
            }
            .form-control{
            border-top: none;
            border-right: none;
            border-left: none;
            }
            .card-footer{
            background-color: transparent;
            }
</style>         
    </head>     
    <body> 
        <center> 
            <div class="container"> 
                <div class="row"> 
                    <div class="col-md-3"></div>                     
                    <div class="col-md-6">
                        <br> 
                        <div class="container">
                            <br> 
                            <div class="card"> 
                                <div class="card-header">
                                    <center>
                                        <h5></h5>
                                    </center>
                                </div>                                 
                                <div class="card-body"> 
                                    <form method="POST" action="login.php"> 
                                        <h2>LOGIN</h2> 
                                        Username : &nbsp
                                        <input type="text" name="username">
                                        <br>
                                        <br> 
                                        Password : &nbsp
                                        <input type="text" name="password">
                                        <br>
                                        <br> 
                                        <div>
                                            <input type="text" class="form-control hidden" placeholder="Placeholder text" value=" <?php 
                        echo date('l-H:i:s-m-d-y')
                     ?> >
                                        </div>                                         
                                    </form>                                     
                                    <form action=" egister.php" method="POST"> 
                                            <br> 
                                            <button type="submit" class="btn btn-outline-success btn-block" name="submit">REGISTER HERE</button>                                             
                                    </form>
                                    <button type="submit" class="btn btn-outline-success " name="btnlogin">LOGIN</button>                                     
                                </div>                                 
                            </div>                             
                        </div>
                        <br> 
                    </div>                     
                    <div class="col-md-3"> 
</div>                     
                </div>                 
            </div>             
        </center>         
    </body>     
</html>