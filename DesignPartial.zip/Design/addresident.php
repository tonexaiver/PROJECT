<?php 
$ln = $_POST['lastname'];
$fn = $_POST['firstname'];
$mn = $_POST['middlename'];
$address = $_POST['address'];
$cs = $_POST['civilstatus'];
$religion= $_POST['Religion'];
$edate=strtotime($_POST['birthdate']); 
$edate=date("Y-m-d",$edate);
$edate1=strtotime($_POST['dateposted2']); 
$edate1=date("Y-m-d",$edate1);

	if (empty($fn)||empty($ln)||empty($mn)||empty($address)||empty($edate)||empty($religion)||empty($edate1)) {
		# code...
		echo "<script>alert('fill out all fields');window.location.href='FinalAdminpanel.php';</script>";
	}
	else
	{
		$con=mysqli_connect('localhost','root','','adweb');
		$query = "INSERT INTO tblresidents
				 (DatePosted, Lastname, Firstname, Middlename, Address, CivilStatus, Religion, Birthdate)
				 VALUES
				 ('edate1', '$ln', '$fn', '$mn', '$address', '$cs', '$religion','$edate')";
		if (mysqli_query($con,$query)) {
			
			echo "<script>alert('Successfully added');window.location.href='FinalAdminpanel.php';</script>";
		}
		else
		{
			echo "<script>alert('Error No Connection');window.location.href='FinalAdminpanel.php';</script>";
		}

	}




?>
<script type="text/javascript">
	$( "#dialog-message" ).dialog({
    modal: true,
    buttons: {
        Ok: function() {
            $( this ).dialog( "close" );
        }
    }
});
</script>