<?php
$con = mysqli_connect('localhost','root','','adweb');
$query2 = "SELECT * FROM tblresidents;";
// $result2 = mysqli_query($con,$query2);
?>
<?php include 'headerstaff.php'; ?>
<link rel="stylesheet" type="text/css" href="mystyle.css">
<style type="text/css">
        .card-body{
            background-color: transparent;
        }
        body{
            background-color: lightgreen
        }
</style>
<body><br><br>
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <form action="" method="POST">
                    <div class="card">
                        <img class="card-img-top" src="image/use.png" alt="Card image cap">
                        <div class="card-header"></div>
                        <div class="card-body">
                            
                            <!-- Material form register -->
                            <form>
                                <p class="h4 text-center mb-4">Sign up</p>

                                <!-- Material input text -->
                                <div class="md-form">
                                    <i class="fa fa-user prefix grey-text"></i>
                                    <input type="text" id="materialFormRegisterNameEx" class="form-control">
                                    <label for="materialFormRegisterNameEx">Your name</label>
                                </div>

                                <!-- Material input email -->
                                <div class="md-form">
                                    <i class="fa fa-envelope prefix grey-text"></i>
                                    <input type="email" id="materialFormRegisterEmailEx" class="form-control">
                                    <label for="materialFormRegisterEmailEx">Your email</label>
                                </div>

                                <!-- Material input email -->
                                <div class="md-form">
                                    <i class="fa fa-exclamation-triangle prefix grey-text"></i>
                                    <input type="email" id="materialFormRegisterConfirmEx" class="form-control">
                                    <label for="materialFormRegisterConfirmEx">Confirm your email</label>
                                </div>

                                <!-- Material input password -->
                                <div class="md-form">
                                    <i class="fa fa-lock prefix grey-text"></i>
                                    <input type="password" id="materialFormRegisterPasswordEx" class="form-control">
                                    <label for="materialFormRegisterPasswordEx">Your password</label>
                                </div>
                                <div class="dropdown">
                                    <button class="btn btn-Secondary dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Select Usertype</button>
                                    <div class="dropdown-menu dropdown-Secondary">
                                        <a class="dropdown-item" href="#">Admin</a>
                                        <a class="dropdown-item" href="#">Staff</a>
                                    </div>
                                </div>

                                <br>
                                <div class="text-center mt-4">
                                    <button class="btn btn-primary" type="submit">Register</button>
                                </div>

                            </form>
                            <!-- Material form register -->
                          
                        </div>
                        <div class="card-footer">
                            <input disabled type="text" class="form-control" name="d" value="<?php date_default_timezone_set('Asia/Manila');
                                        echo date('l-h:i:s-(m-d-20y)');
                                        ?> ">
                        </div>
                    </div>
                </form>
                
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
</body>
<?php include 'footer.php';?>
