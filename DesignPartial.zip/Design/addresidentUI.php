
<?php require 'headerstaff.php';?>

    <!--Main layout-->
    <main>
        <!--Section: Main panel-->
                <section class="card card-cascade narrower">

                    <!--Grid row-->
                    <div class="row">
                    
                    <!--Grid column-->
                    <div class="col-md-12" style=" height: 480px;">
                        <!--Panel Header-->
                        <div class="view py-3 gradient-card-header" style="background-color: #3f5c80 ; font-family: Century Gothic ; font-size: 20px; text-align: left">
                            <div class="row">
                                <div class="col-md-8">
                                    <i class="fa fa-folder-open"></i>
                            ADD RESIDENT
                           
                                </div>
                                <div class="col-md-4">
                                    <a class="btn-floating btn-small blue" style="float: right" ripple-radius><i class="fa fa-plus"></i></a>
                                    <a class="btn-floating btn-small blue" style="float: right" ripple-radius><i class="fa fa-backward"></i></a>
                                 </div>
                            </div>
                        </div>
                        <!--/Panel Header-->

                        <!--Panel content-->
                        <div class="card-body">

                            <!--Grid row-->
                            <div class="row">

                                <!--Grid column-->
                                <div class="col-md-6">
                                    <div class="card" style="height: 380px; background-color: #e9ebee">
                                        <div class="card-body">
                                            <p class="card-title" style="color: #3f5c80; font-family: century gothic; font-size: 25px;"> Personal Information</p>
                                           
                                             <div class="row">
                                                <div class="col-md-4">
                                                    <div class="md-form ">
                                                        <input type="email" class="form-control">
                                                        <label >Firstname</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                     <div class="md-form ">
                                                        <input type="email"  class="form-control">
                                                        <label >Middle Name</label>
                                                     </div>
                                                </div>
                                                <div class="col-md-4">
                                                     <div class="md-form ">
                                                        <input type="email" " class="form-control">
                                                     <label >Last Name</label>
                                                    </div>
                                                </div>
                                             </div>

                                             <div class="row">
                                                <div class="col-md-6">
                                                    <div class="md-form ">
                                                        <input placeholder="Selected date" type="text" id="date-picker-example" class="form-control datepicker">
                                                        <label for="date-picker-example">Birthdate</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="md-form">
                                                    
                                                    <input type="email" " class="form-control">
                                                    <label >Birthplace</label>
                                                </div>
                                                </div>
                                                 
                                             </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="md-form ">
                                                    <select class="mdb-select" style="color: #3f5c80">
                                                        <option value="" style="color: #3f5c80" disabled selected>Choose your option</option>
                                                        <option value="1" style="color: #3f5c80">Male</option>
                                                        <option value="2" style="color: #3f5c80">Female</option>
                                                      >
                                                    </select>
                                                    <label style="color: #3f5c80">Gender</label>
                                                </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="md-form ">
                                                    <select class="mdb-select">
                                                        <option value="" disabled selected>Choose your option</option>
                                                        <option value="1">Single</option>
                                                        <option value="2">Married</option>
                                                        <option value="1">Divorced</option>
                                                        <option value="2">Widowed</option>
                                                      >
                                                    </select>
                                                    <label>Civil status</label>
                                                </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="md-form ">
                                                      <select class="mdb-select">
                                                        <option value="" disabled selected>Choose your option</option>
                                                        <option value="1">Roman Catholic</option>
                                                        <option value="2">INC</option>
                                                        <option value="2">Bornagain</option>
                                                      >
                                                    </select>
                                                    <label>Religion</label>
                                                </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                 <div class="col-md-12">
                                                <div class="md-form">
                                                    <input type="email" " class="form-control">
                                                    <label >Address</label>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--Grid column-->

                                <!--Grid column-->
                                  <div class="col-md-6">
                                    <div class="card" style="height: 380px; background-color: #e9ebee">
                                        <div class="card-body">
                                            <p class="card-title" style="color: #3f5c80; font-family: century gothic; font-size: 25px;"> Family Information</p>
                                           <!--Fathers row-->
                                             <div class="row">
                                                <div class="col-md-8">
                                                    <div class="md-form ">
                                                        <input type="email" class="form-control">
                                                        <label >Father's Name</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                     <div class="md-form ">
                                                        <input type="email"  class="form-control">
                                                        <label >Occupation</label>
                                                     </div>
                                                </div>  
                                             </div>
                                           <!-- end Fathers row-->
                                               <div class="row">
                                                <div class="col-md-8">
                                                    <div class="md-form ">
                                                        <input type="email" class="form-control">
                                                        <label >Mother's Name</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                     <div class="md-form ">
                                                        <input type="email"  class="form-control">
                                                        <label >Occupation</label>
                                                     </div>
                                                </div>  
                                             </div>
                                           <!--Mothers row-->
                                             
                                             <!-- end Mothers row-->
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="md-form ">
                                                    <input type="email" " class="form-control">
                                                    <label >Gender</label>
                                                </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="md-form ">
                                                    <input type="email" " class="form-control">
                                                    <label >Civil Status</label>
                                                </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="md-form ">
                                                    <input type="email" " class="form-control">
                                                    <label >Religion</label>
                                                </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                 <div class="col-md-12">
                                                <div class="md-form">
                                                    <input type="email" " class="form-control">
                                                    <label >Address</label>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--Grid column-->
                                

                            </div>
                            <!--Grid row-->

                        </div>
                        <!--Panel content-->
                    
                    
                    </div>
                    <!--Grid column-->
                    
                    
                    
                    </div>
                    <!--Grid row-->

                </section>
                <!--Section: Main panel-->
    
    </main>
    <!--Main layout-->

    
   
    

 <?php require 'footer.php';?>  
