<div class="heads">
<?php include 'header4staff.php'; ?>
</div>
<?php

$id=$_GET['id'];

$con=mysqli_connect('localhost','root','','fmsg9');

$query = "select * from tblbpermit where id=".$id;

$result = mysqli_query($con, $query);

$row = mysqli_fetch_array($result);





?>
<style type="text/css">
    #btnprint2{
        float: right;
    }
 </style>
<main>
    <section>
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                

                <div class="col-md-12">
                <form action="Bpermitform.php" class="form1" method="POST">
                    <div class="row">
                    <div class="col-md-12">
                        <div class="md-form ">
                            <input type="text" value = "<?php echo $row['Fullname']; ?>" name="fullname" id="fullname" class="form-control">
                            <label for="name" >Full name</label>
                        </div>
                    </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="md-form ">
                                <input type="text" name="type" value = "<?php echo $row['BusinessType']; ?>" class="form-control">
                                <label>Business Type</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="md-form ">
                                <input type="text" name="dates" value = "<?php echo $row['Date']; ?>" class="form-control">
                                <label>Date</label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                    <div class="col-md-12">
                        <div class="md-form ">
                            <input type="text" name="orno" value = "<?php echo $row['Orno']; ?>" class="form-control">
                            <label for="name">O.R code</label>
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-md-12">
                        <div class="md-form ">
                            <input type="text" name="amount" value = "<?php echo $row['Amount']; ?>" class="form-control">
                            <label for="name">Amount</label>
                        </div>
                    </div>
                    </div>
                   
                    
                    <button type="submit" name="submit" id="submit" class="btn btn-indigo" style="float: right">
                        Show Clearance<i class="fa fa-paper-plane-o ml-2"></i>
                    </button>
                    <a href="Bpermitshow.php" id="btnprint2" style="color:white;"><button"  class="btn btn-orange">
                        Back<i class="fa fa-hand-pointer-o ml-2"></i>
                    </button></a>
                      
                    
                    
                    
                    </form>  
                </div>
                

                                                
            </div>
            <div class="col-md-3">
            </div>
        </div>
    </section>
</main>
<div class="foot">
    <?php include 'footer.php';?>
</div>
