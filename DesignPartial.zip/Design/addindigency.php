<?php
$flname = $_POST['fullname'];
$age = $_POST['age'];
$purok = $_POST['purok'];
$day = $_POST['day'];
$month = $_POST['month'];
$year = $_POST['year'];
$purpose = $_POST['purpose'];

	if (empty($fln)||empty($age)||empty($purok)||empty($day)||empty($month) || empty($year) || empty($purpose)) {
		# code...
		echo "<script>alert('fill out all fields');window.location.href='FinalAdminPanel';</script>";
	}
	else
	{
		$con=mysqli_connect('localhost','root','','ADWEB');
		$query = "INSERT INTO INDIGENCY
				 (Fullname, Age, Purok, Day, Month, Year, Purpose)
				 VALUES
				 ('$fln','$age','$purok','$day','$month','year','purpose')";
		if (mysqli_query($con,$query)) {
			# code...
			echo "<script>alert('Successfully added');window.location.href='Viewing.php';</script>";
		}
		else
		{
			echo "<script>alert('Error No Connection');window.location.href='#';</script>";
		}		}
		

	}





?>