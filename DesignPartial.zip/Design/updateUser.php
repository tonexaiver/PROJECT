<?php 
if(isset($_POST['btnUpdate']))
{
	$con2=mysqli_connect('localhost','root','','adweb');

	$id = $_POST["id"];
	$dateposted = $_POST["dateposted"];
	$username = $_POST["username"];
	$email = $_POST["email"];

	$password = $_POST["password"];


	$type = $_POST["type"];
	
	//create query
	$query= "UPDATE tbluser SET Username='$username', Email='$email', Password='$password', Type='$type', Dateposted='$dateposted' WHERE UserID='".$id."';";
	//execute query
	if(mysqli_query($con2,$query))
	{
		//create messagebox for displaying successfully update!
		echo "<script>alert('Successfully Updated!');window.location.href='allrecords.php';</script>";
	}
	else
	{
		echo "<script>alert('Successfully Not Updated!');window.location.href='allrecords.php';</script>";

	}
	
}
?>