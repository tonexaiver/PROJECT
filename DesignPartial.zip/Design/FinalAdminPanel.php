<div class="heads">
    <?php include 'header4admin.php';?>
</div>





    <!--Main layout-->
    <main>

        <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-2"><img src="image/head.png" class="mx-auto d-block animated fadeInLeft image-responsive" style="width: auto;height: auto; position: center"></div>
        <div class="col-md-6 animated fadeInDownBig" style="text-align: center; font-size: 200%; font-family: century gothic;"> WELCOME TO POBLACION WARD IV <p style="text-align: center; font-size: 60%; font-family: century gothic;">Purok 2, Ward 4, Minglanilla, Cebu <br> TIN 004238395000 Tel. 238-5424 <br> PSGC 072232013 <br> E-mail: ward4minglanilla@gmail.com <br> FB Page: New Barangay Ward IV</p> 
        </div>
        <div class="col-md-1">
            <img src="image/der.png" class="mx-auto d-block animated fadeInRight image-responsive" style="width: auto;height: auto; position: center">
        </div>

        <div class="col-md-2"></div>
        </div>
        <hr>

        <div class="row">
            <div class="col-md-8 animated flipInX" style="height: 500px; border-right: 10px solid white;">
              
                <!--Section: Main panel-->
                <section class="card card-cascade narrower mb-5">

                    <!--Grid row-->
                    <div class="row">
                    
                    <!--Grid column-->
                    <div class="col-md-12" style=" height: 483px;">
                        <!--Panel Header-->
                        <div class="view py-3 gradient-card-header" style="background-color: #3f5c80 ; font-family: Century Gothic ; font-size: 20px;">
                            CURRENT BARANGAY OFFICIALS
                        </div>
                        <!--/Panel Header-->

                        <!--Panel content-->
                        <div class="card-body">

                            <!--Grid row-->
                            <div class="row">

                                <!--Grid column-->
                                <div class="col-md-6 mb-4">



                                </div>
                                <!--Grid column-->

                                <!--Grid column-->
                                <div class="col-md-6 mb-4 text-center">



                                </div>
                                <!--Grid column-->

                            </div>
                            <!--Grid row-->

                        </div>
                        <!--Panel content-->
                    
                    
                    </div>
                    <!--Grid column-->
                    
                    
                    
                    </div>
                    <!--Grid row-->

                </section>
                <!--Section: Main panel-->
    
            </div>
            <div class="col-md-4 animated zoomInDown" style="height: 500px;">
                <!-- Rotating card -->
                <div class="card-wrapper">
                  <div id="card-1" class="card-rotating effect__click text-center h-100 w-100">

                    <!-- Front Side -->
                    <div class="face front">

                      <!-- Image-->
                      <div class="card-up">
                        <img  class="card-img-top" src="image/img.jpg">
                      </div>

                      <!-- Avatar -->
                      <div class="avatar mx-auto white"><img src="image/officiallogo.png" alt="Sample avatar image.">
                      </div>

                      <!-- Content -->
                      <div class="card-body">
                        <p style="font-family: century gothic; font-size: 40px;">WELCOME</p>
                        <input type="text" name="user" style="color: black; text-align: center;" value = "<?php echo $row['Username']; ?>">
                        <p class="font-weight-bold blue-text">Barangay Captain</p>
                        <!-- Triggering button -->
                        <a class="rotate-btn" data-card="card-1"><i class="fa fa-repeat"></i> Click here to rotate</a>
                      </div>
                    </div>
                    <!-- Front Side -->

                    <!-- Back Side -->
                    <div class="face back">
                      <div class="card-body">

                        <!-- Content -->
                        <div class="row" style=" margin-bottom: 30px">
                          <div class="col-md-6">
                           <div class="card">
                              <div class="aqua-gradient" style="font-family: :century gothic;">Population</div>
                                    <p class="" style="font-size: 20px; padding-top: 15px;">1000</p>      
                                </div>
                                </div>
                            <div class="col-md-6">
                                 <div class="card">
                                      <div class="aqua-gradient" style="font-family: :century gothic;">Households</div>
                                        <p class="" style="font-size: 20px; padding-top: 15px;">630</p>      
                                    </div>
                            </div>
                                
                            </div>

                             <div class="row" style=" margin-bottom: 30px">
                          <div class="col-md-6">
                           <div class="card">
                              <div class="aqua-gradient" style="font-family: :century gothic;">transcients</div>
                                    <p class="" style="font-size: 20px; padding-top: 15px;">370</p>      
                                </div>
                                </div>
                            <div class="col-md-6">
                                 <div class="card">
                                      <div class="aqua-gradient" style="font-family: :century gothic;">Gov. employed</div>
                                        <p class="" style="font-size: 20px; padding-top: 15px;">425</p>      
                                    </div>
                            </div>
                                
                            </div>

                             <div class="row" style=" margin-bottom: 30px">
                          <div class="col-md-6">
                           <div class="card">
                              <div class="aqua-gradient" style="font-family: :century gothic;">Unemployed</div>
                                    <p class="" style="font-size: 20px; padding-top: 15px;">210</p>      
                                </div>
                                </div>
                            <div class="col-md-6">
                                 <div class="card">
                                      <div class="aqua-gradient" style="font-family: :century gothic;">Private Employed</div>
                                        <p class="" style="font-size: 20px; padding-top: 15px;">365</p>      
                                    </div>
                            </div>
                                
                            </div>

                             <div class="row" >
                          <div class="col-md-6">
                           <div class="card">
                              <div class="aqua-gradient" style="font-family: :century gothic;">Retired</div>
                                    <p class="" style="font-size: 20px; padding-top: 15px;">158</p>      
                                </div>
                                </div>
                            <div class="col-md-6">
                                 <div class="card">
                                      <div class="aqua-gradient" style="font-family: :century gothic;">Establisments</div>
                                        <p class="" style="font-size: 20px; padding-top: 15px;">352</p>      
                                    </div>
                            </div>
                                
                            </div>
                            
                        </div>
                        
                        <!-- Triggering button -->
                        <a class="rotate-btn" data-card="card-1"><i class="fa fa-undo"></i> Click here to rotate back</a>

                      </div>
                    </div>
                    <!-- Back Side -->

                  </div>
                </div>
                <!-- Rotating card -->
            
            </div>
        </div>
    </main>
    <!--Main layout-->
 <?php require 'allmodals.php';?>
 <?php require 'footer.php';?>  
