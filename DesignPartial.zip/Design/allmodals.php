<!--log out Modal-->
<div class="modal fade custom-scrollbar list-unstyled" id="Logout" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog cascading-modal" role="document">
            <!--Content-->
            <div class="modal-content">
    
                <!--Body-->
                <div class="modal-body">
                    <p style="text-align: center; font-family: century gothic; font-size: 25px;">Are you sure you want to log out?</p>

                  <div class="row">
                      <div class="col-md-2 ml-4"></div>
                      <div class="col-md-3"> <div class="text-center mt-2">
                        <button class="btn btn-info" data-dismiss="modal" >No</button>
                    </div></div>
                      <div class="col-md-1"></div>
                      <div class="col-md-3"><div class="text-center mt-2">
                        <button class="btn btn-info"><a href="logini.php" style="color: white;">Yes</a></button>
                    </div></div>
                      <div class="col-md-3"></div>

                  </div>
                
                   
                    
    
                </div>
                </form>
                <!--Footer-->
                
            </div>
            <!--/.Content-->
        </div>
    </div>
    <!-- end add user Modal-->