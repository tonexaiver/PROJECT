<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/mdb/mdb.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/mdb/compiled.min.css">
    <style type="text/css">.table-wrapper {
    display: block;
    max-height: 300px;
    overflow-y: auto;
    -ms-overflow-style: -ms-autohiding-scrollbar;
}</style>
<body>
<div class="card p-2 mb-5">

    <!--Grid row-->
    <div class="row">

        <!--Grid column-->
        <div class="col-lg-3 col-md-12">

            <!--Name-->
            <select class="mdb-select colorful-select dropdown-primary mx-2">
                <option value="" disabled selected>Bulk actions</option>
                <option value="1">Delate</option>
                <option value="2">Export</option>
                <option value="3">Change segment</option>
            </select>

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6">

            <!--Blue select-->
            <select class="mdb-select colorful-select dropdown-primary mx-2">
                <option value="" disabled selected>Show only</option>
                <option value="1">All <span> (2000)</span></option>
                <option value="2">Never opened <span> (200)</span></option>
                <option value="3">Opened but unanswered <span> (1800)</span></option>
                <option value="4">Answered <span> (200)</span></option>
                <option value="5">Unsunscribed <span> (50)</span></option>
            </select>
            <!--/Blue select-->

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6">

            <!--Blue select-->
            <select class="mdb-select colorful-select dropdown-primary mx-2">
                <option value="" disabled selected>Filter segments</option>
                <option value="1">Contacts in no segments <span> (100)</span></option>
                <option value="1">Segment 1 <span> (2000)</span></option>
                <option value="2">Segment 2 <span> (1000)</span></option>
                <option value="3">Segment 3 <span> (4000)</span></option>
            </select>
            <!--/Blue select-->

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6">

            <form class="form-inline mt-2 ml-2">
                <input class="form-control my-0 py-0" type="text" placeholder="Search" style="max-width: 150px;">
                <button class="btn btn-sm btn-primary ml-2 px-1"><i class="fa fa-search"></i>  </button>
            </form>

        </div>
        <!--Grid column-->

    </div>
    <!--Grid row-->

</div>
<!--Top Table UI-->

<div class="card card-cascade narrower">

    <!--Card image-->
    <div class="view gradient-card-header blue-gradient narrower py-2 mx-4 mb-3 d-flex justify-content-between align-items-center">

        <div>
            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2"><i class="fa fa-th-large mt-0"></i></button>
            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2"><i class="fa fa-columns mt-0"></i></button>
        </div>

        <a href="" class="white-text mx-3">Table name</a>

        <div>
            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2"><i class="fa fa-pencil mt-0"></i></button>
            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2"><i class="fa fa-remove mt-0"></i></button>
            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2"><i class="fa fa-info-circle mt-0"></i></button>
        </div>

    </div>
    <!--/Card image-->

    <div class="px-4">

        <div class="table-wrapper">
            <!--Table-->
            <table class="table table-hover mb-0">

                <!--Table head-->
                <thead>
                    <tr>
                        <th>
                            <input type="checkbox" id="checkbox">
                            <label for="checkbox" class="mr-2 label-table"></label>
                        </th>
                        <th class="th-lg"><a>First Name <i class="fa fa-sort ml-1"></i></a></th>
                        <th class="th-lg"><a href="">Last Name<i class="fa fa-sort ml-1"></i></a></th>
                        <th class="th-lg"><a href="">Username<i class="fa fa-sort ml-1"></i></a></th>
                        <th class="th-lg"><a href="">Username<i class="fa fa-sort ml-1"></i></a></th>
                        <th class="th-lg"><a href="">Username<i class="fa fa-sort ml-1"></i></a></th>
                        <th class="th-lg"><a href="">Username<i class="fa fa-sort ml-1"></i></a></th>
                    </tr>
                </thead>
                <!--Table head-->

                <!--Table body-->
                <tbody>
                    <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox1">
                            <label for="checkbox1" class="label-table"></label>
                        </th>
                        <td>Mark</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>Mark</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox2">
                            <label for="checkbox2" class="label-table"></label>
                        </th>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>@fat</td>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>@fat</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox3">
                            <label for="checkbox3" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox4">
                            <label for="checkbox4" class="label-table"></label>
                        </th>
                        <td>Paul</td>
                        <td>Topolski</td>
                        <td>@P_Topolski</td>
                        <td>Paul</td>
                        <td>Topolski</td>
                        <td>@P_Topolski</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                      <tr>
                        <th scope="row">
                            <input type="checkbox" id="checkbox5">
                            <label for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                </tbody>
                <!--Table body-->
            </table>
            <!--Table-->
        </div>

        <hr class="my-0">

        <!--Bottom Table UI-->
        <div class="d-flex justify-content-between">

            <!--Name-->
            <select class="mdb-select colorful-select dropdown-primary mt-2 hidden-md-down">
                <option value="" disabled >Rows number</option>
                <option value="1" selected>10 rows</option>
                <option value="2">25 rows</option>
                <option value="3">50 rows</option>
                <option value="4">100 rows</option>
            </select>

            <!--Pagination -->
            <nav class="my-4">
                <ul class="pagination pagination-circle pg-blue mb-0">

                    <!--First-->
                    <li class="page-item disabled"><a class="page-link">First</a></li>

                    <!--Arrow left-->
                    <li class="page-item disabled">
                        <a class="page-link" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                        <span class="sr-only">Previous</span>
                    </a>
                    </li>

                    <!--Numbers-->
                    <li class="page-item active"><a class="page-link">1</a></li>
                    <li class="page-item"><a class="page-link">2</a></li>
                    <li class="page-item"><a class="page-link">3</a></li>
                    <li class="page-item"><a class="page-link">4</a></li>
                    <li class="page-item"><a class="page-link">5</a></li>

                    <!--Arrow right-->
                    <li class="page-item">
                        <a class="page-link" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                        <span class="sr-only">Next</span>
                    </a>
                    </li>

                    <!--First-->
                    <li class="page-item"><a class="page-link">Last</a></li>

                </ul>
            </nav>
            <!--/Pagination -->

        </div>
        <!--Bottom Table UI-->

    </div>
</div>
<button class="btn peach-gradient btn-rounded">Peach</button>
<button class="btn purple-gradient btn-rounded">Purple</button>
<button class="btn blue-gradient btn-rounded">Blue</button>
<button class="btn aqua-gradient btn-rounded">Aqua</button>

<a class="btn-floating btn-lg purple-gradient"><i class="fa fa-bolt"></i></a>
<a class="btn-floating peach-gradient"><i class="fa fa-leaf"></i></a>
<a class="btn-floating btn-sm blue-gradient"><i class="fa fa-star"></i></a>

<div class="fixed-action-btn" style="bottom: 45px; right: 24px;">
    <a class="btn-floating btn-lg red">
        <i class="fa fa-pencil"></i>
    </a>

    <ul class="list-unstyled">
        <li><a class="btn-floating red"><i class="fa fa-star"></i></a></li>
        <li><a class="btn-floating yellow darken-1"><i class="fa fa-user"></i></a></li>
        <li><a class="btn-floating green"><i class="fa fa-envelope"></i></a></li>
        <li><a class="btn-floating blue"><i class="fa fa-shopping-cart"></i></a></li>
    </ul>
</div>

    <!--Card-->
    <div class="card card-cascade wider reverse my-4">

        <!--Card image-->
        <div class="view overlay">
            <img src="https://mdbootstrap.com/img/Photos/Slides/img%20(70).jpg" class="img-fluid">
            <a href="#!">
                <div class="mask rgba-white-slight"></div>
            </a>
        </div>
        <!--/Card image-->

        <!--Card content-->
        <div class="card-body text-center">
            <!--Title-->
            <h4 class="card-title"><strong>My adventure</strong></h4>
            <h5 class="indigo-text"><strong>Photography</strong></h5>

            <p class="card-text">Sed ut perspiciatis unde omnis iste natus sit voluptatem accusantium doloremque laudantium, totam rem aperiam.
            </p>

            <!--Linkedin-->
            <a class="icons-sm li-ic"><i class="fa fa-linkedin"> </i></a>
            <!--Twitter-->
            <a class="icons-sm tw-ic"><i class="fa fa-twitter"> </i></a>
            <!--Dribbble-->
            <a class="icons-sm fb-ic"><i class="fa fa-facebook"> </i></a>

        </div>
        <!--/.Card content-->

    </div>
    <!--/.Card-->



    <!--Card-->
    <div class="card">
      <!--Card image-->
      <div class="view overlay">
        <img src="https://mdbootstrap.com/img/Photos/Others/food.jpg" class="img-fluid" alt="sample">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>
      <!--/.Card image-->
      <!--Button-->
      <a class="btn-floating btn-action ml-auto mr-4 mdb-color lighten-3"><i class="fa fa-chevron-right pl-1"></i></a>
      <!--Card content-->
      <div class="card-body">
        <!--Title-->
        <h4 class="card-title">Card title</h4>
        <hr>
        <!--Text-->
        <p class="font-small grey-dark-text mb-0">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <!--/.Card content-->
      <!-- Card footer -->
      <div class="mdb-color lighten-3 text-center">
        <ul class="list-unstyled list-inline font-small mt-3">
          <li class="list-inline-item pr-2 white-text"><i class="fa fa-clock-o pr-1"></i>05/10/2015</li>
          <li class="list-inline-item pr-2"><a href="#" class="white-text"><i class="fa fa-comments-o pr-1"></i>12</a></li>
          <li class="list-inline-item pr-2"><a href="#" class="white-text"><i class="fa fa-facebook pr-1"> </i>21</a></li>
          <li class="list-inline-item"><a href="#" class="white-text"><i class="fa fa-twitter pr-1"> </i>5</a></li>
        </ul>
      </div>
      <!-- Card footer -->
    </div>
    <!--/.Card-->
                  
                      <!-- Card -->
<div class="card card-image" style="background-image: url(https://mdbootstrap.com/img/Photos/Horizontal/Work/4-col/img%20%2814%29.jpg);">

    <!-- Content -->
    <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
        <div>
            <h5 class="pink-text"><i class="fa fa-pie-chart"></i> Marketing</h5>
            <h3 class="card-title pt-2"><strong>This is card title</strong></h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat fugiat, laboriosam, voluptatem,
                optio vero odio nam sit officia accusamus minus error nisi architecto nulla ipsum dignissimos.
                Odit sed qui, dolorum!.</p>
            <a class="btn btn-pink"><i class="fa fa-clone left"></i> View project</a>
        </div>
    </div>
    <!-- Content -->
</div>
<!-- Card -->

<!--Card group-->
<div class="card-group">

    <!--Card-->
    <div class="card mb-4">

        <!--Card image-->
        <div class="view overlay">
            <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/49.jpg" alt="Card image cap">
            <a href="#!">
                <div class="mask rgba-white-slight"></div>
            </a>
        </div>
        <!--Card image-->

        <!--Card content-->
        <div class="card-body">

            <!--Title-->
            <h4 class="card-title">Card title</h4>

            <!--Text-->
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>

            <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
            <button type="button" class="btn btn-primary btn-md">Read more</button>
        </div>
        <!--Card content-->

    </div>
    <!--Card-->

    <!--Card-->
    <div class="card mb-4">

        <!--Card image-->
        <div class="view overlay">
            <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/48.jpg" alt="Card image cap">
            <a href="#!">
                <div class="mask rgba-white-slight"></div>
            </a>
        </div>
        <!--Card image-->

        <!--Card content-->
        <div class="card-body">
            <!--Title-->
            <h4 class="card-title">Card title</h4>

            <!--Text-->
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>

            <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
            <button type="button" class="btn btn-primary btn-md">Read more</button>
        </div>
        <!--Card content-->

    </div>
    <!--Card-->

    <!--Card-->
    <div class="card mb-4">

        <!--Card image-->
        <div class="view overlay">
            <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/77.jpg" alt="Card image cap">
            <a href="#!">
                <div class="mask rgba-white-slight"></div>
            </a>
        </div>
        <!--Card image-->

        <!--Card content-->
        <div class="card-body">
            <!--Title-->
            <h4 class="card-title">Card title</h4>

            <!--Text-->
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>

            <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
            <button type="button" class="btn btn-primary btn-md">Read more</button>
        </div>
        <!--Card content-->

    </div>
    <!--Card-->

</div>
<!--Card group-->
                        
       <!--Card group-->
    <div class="card-deck">

        <!--Card-->
        <div class="card mb-4">

            <!--Card image-->
            <div class="view overlay">
                <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/16.jpg" alt="Card image cap">
                <a href="#!">
                    <div class="mask rgba-white-slight"></div>
                </a>
            </div>
            <!--Card image-->

            <!--Card content-->
            <div class="card-body">

                <!--Title-->
                <h4 class="card-title">Card title</h4>

                <!--Text-->
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>

                <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
                <button type="button" class="btn btn-light-blue btn-md">Read more</button>
            </div>
            <!--Card content-->

        </div>
        <!--Card-->

        <!--Card-->
        <div class="card mb-4">

            <!--Card image-->
            <div class="view overlay">
                <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/14.jpg" alt="Card image cap">
                <a href="#!">
                    <div class="mask rgba-white-slight"></div>
                </a>
            </div>
            <!--Card image-->

            <!--Card content-->
            <div class="card-body">
                <!--Title-->
                <h4 class="card-title">Card title</h4>

                <!--Text-->
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>

                <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
                <button type="button" class="btn btn-light-blue btn-md">Read more</button>
            </div>
            <!--Card content-->

        </div>
        <!--Card-->

        <!--Card-->
        <div class="card mb-4">

            <!--Card image-->
            <div class="view overlay">
                <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/15.jpg" alt="Card image cap">
                <a href="#!">
                    <div class="mask rgba-white-slight"></div>
                </a>
            </div>
            <!--Card image-->

            <!--Card content-->
            <div class="card-body">
                <!--Title-->
                <h4 class="card-title">Card title</h4>

                <!--Text-->
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>

                <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
                <button type="button" class="btn btn-light-blue btn-md">Read more</button>
            </div>
            <!--Card content-->

        </div>
        <!--Card-->

    </div>
    <!--Card group-->    

    <!-- Grid row -->
<div class="row">

    <!-- Grid column -->
    <div class="col-md-10 col-lg-9 col-xl-6 mb-r">
        
        <!--Panel-->
        <div class="card card-body mb-3">
            <div class="media d-block d-md-flex">
                <img class="d-flex avatar-2 mb-md-0 mb-3 mx-auto" src="https://mdbootstrap.com/img/Photos/Avatars/img (31).jpg" alt="Generic placeholder image">
                <div class="media-body text-center text-md-left ml-md-3 ml-0">
                    <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia magni dolores eos qui ratione voluptatem
                            sequi nesciunt.</p>
                    <button type="button" class="btn btn-primary btn-md">Read more</button>
                </div>
            </div>
        </div>
        <!--/.Panel-->

        <!--Panel-->
        <div class="card card-body mb-3">
            <div class="media d-block d-md-flex">
                <div class="media-body pr-md-3 pr-0 text-center text-md-left">
                    <p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit.</p>
                    <button type="button" class="btn btn-primary btn-md">Read more</button>
                </div>
                <img class="d-flex mr-3 avatar-2 mt-md-0 mt-3 mx-auto" src="https://mdbootstrap.com/img/Photos/Avatars/img (27).jpg" alt="Generic placeholder image">
            </div>z
        </div>
        <!--/.Panel-->

        <!--Panel-->
        <div class="card card-body">
            <div class="media d-block d-md-flex">
                <img class="d-flex avatar-2 mb-md-0 mb-3 mx-auto" src="https://mdbootstrap.com/img/Photos/Avatars/img (28).jpg" alt="Generic placeholder image">
                <div class="media-body text-center text-md-left ml-md-3 ml-0">
                    <p> Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis
                        voluptas assumenda est, omnis dolor repellendus. Itaque earum rerum hic tenetur a sapiente delectus.</p>
                </div>
            </div>
        </div>
        <!--/.Panel-->

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-md-10 col-lg-9 col-xl-6">

        <!--Panel-->
        <div class="card mb-3">
            <h3 class="card-header indigo white-text text-uppercase text-center">Authors</h3>
            <div class="card-body">
                <div class="media d-block d-md-flex mt-md-0 mt-4 mb-4">
                    <img class="d-flex mb-md-0 mb-3 avatar-2 rounded-circle z-depth-1 mx-auto" src="https://mdbootstrap.com/img/Photos/Avatars/img (3).jpg" alt="An image">
                    <div class="media-body ml-md-3 ml-0">
                        <p align="justify">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti
                            quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est
                            laborum et dolorum fuga.</p>
                        <div class="text-center text-md-left">
                            <button type="button" class="btn btn-indigo btn-rounded btn-md">Read more</button>
                        </div>
                    </div>
                </div>

                <div class="media d-block d-md-flex">
                    <div class="media-body mr-md-3 mr-0">
                        <p align="justify">Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque
                            nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut
                            officiis.</p>
                        <div class="text-center text-md-left">
                            <button type="button" class="btn btn-indigo btn-rounded btn-md">Read more</button>
                        </div>
                    </div>
                    <img class="d-flex mr-3 mb-md-0 mb-3 mt-md-0 mt-4 avatar-2 rounded-circle z-depth-1 mx-auto" src="https://mdbootstrap.com/img/Photos/Avatars/img (2).jpg"
                        alt="Generic placeholder image">
                </div>
            </div>
        </div>
        <!--/.Panel-->

    </div>
    <!-- Grid column -->

</div>
<!-- Grid row -->             


<script type="text/javascript" src="jquery/jquery.js"></script>
<script type="text/javascript" src="popper/popper.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="jquery/mdb.js"></script>
</body>
</html>