<?php 
$un=$_POST['username'];
$ps=$_POST['password'];
$conpass=$_POST['conpass'];
$Rec=$_POST['recoverpass'];
$type=$_POST['type'];
$edate=strtotime($_POST['dateposted']); 
$edate1=date("Y-m-d",$edate);
$date = date('Y-m-d H:i:s');

if (empty($un)||empty($Rec)||empty($ps)||empty($conpass)||empty($type)||empty($edate)) {
	
	echo "<script>alert('fill out all fields');window.location.href='adduserUI.php';</script>";
}
else if ($ps!=$conpass)
{
	echo "<script>alert('The password mismatch!');window.location.href='adduserUI.php';</script>";
}
else
{
	$con = mysqli_connect('localhost','root','','fmsg9');

	$query = "INSERT INTO tblusers
			(Username, Password, Usertype, RecoveryPass, DateAdded)
			VALUES
			('$un','$ps','$type','$Rec','$date')";

	if (mysqli_query($con,$query)) {
		
		echo "<script>alert('successfully added');window.location.href='FinalAdminpanel.php';</script>";
	}
	else
		{
			echo "<script>alert('Registration Failed!! Check your entry for errors!');</script>";
		}
}



?>