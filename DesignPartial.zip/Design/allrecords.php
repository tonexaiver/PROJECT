<?php
$con = mysqli_connect('localhost','root','','adweb');
$query = "SELECT * FROM staff;";
$query1 = "SELECT * FROM tbluser;";
$query2 = "SELECT * FROM tblresidents;";
$result = mysqli_query($con,$query);
$result1 = mysqli_query($con,$query1);
$result2 = mysqli_query($con,$query2);

?>
<?php require 'header.php';?>
<main>
    <div class="container-fluid">
        <section>
            <div>
                <ul class="nav nav-tabs nav-justified">
    <li class="nav-item">
        <a class="nav-link active" data-toggle="tab" href="#panel1" role="tab">STAFF LIST</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#panel2" role="tab">USER LIST</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#panel3" role="tab">RESIDENTS RECORDS</a>
    </li>
</ul>
<!-- Tab panels -->
<div class="tab-content card">
    <!--Panel 1-->
    <div class="tab-pane fade in show active" id="panel1" role="tabpanel">
        <h5 class="my-2 h5 text-center">BARANGGAY STAFF</h5>

                        <form>
                        <div class="table-responsive">
        <table id="stafftable" class="table stripe hover order-column row-border">
            <thead>
            <tr>
                <th>StaffID</th>
                <th>Lastname</th>
                <th>Firstname</th>
                <th>Address</th>
                <th>Birthdate</th>
                <th>Position</th>
                <th>DatePosted</th>
                <th>ACTION</th>
            </tr>
            </thead>

            <tbody>
                <?php 
                while ($row = mysqli_fetch_array($result)) {
                    # code...
                    echo "<tr>";
                    echo "<td>".$row['StaffID']."</td>";
                    echo "<td>".$row['lastname']."</td>";
                    echo "<td>".$row['firstname']."</td>";
                    echo "<td>".$row['address']."</td>";
                    echo "<td>".$row['birthdate']."</td>";
                    echo "<td>".$row['position']."</td>";
                    echo "<td>".$row['dateposted']."</td>";
                    echo "<td><button class='btn btn-info'><a class='white-text' href='Editstaff.php?id=".$row['StaffID']."&action=edit'>EDIT</a></button><button class='btn btn-danger btn-md'><a class='white-text' href='deleteStaff.php?id=".$row['StaffID']."&action=delete'>DELETE</a></button></td>";
                    echo "</tr>";
                }

                ?>
            </tbody>
        </table>
        </div>
    </form>
    </div>
    <!--/.Panel 1-->
    <!--Panel 2-->
    <div class="tab-pane fade" id="panel2" role="tabpanel">
       <h5 class="my-2 h5 text-center">REGISTERED USERS</h5>
                                  <form><div class="table-responsive">
        <table id="userstable" class="table stripe hover order-column row-border">
            <thead>
            <tr>
                <th>UserID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Type</th>
                <th>DatePosted</th>
                <th>ACTION</th>


                
            </tr>
            </thead>

            <tbody>
                <?php 
                while ($row = mysqli_fetch_array($result1)) {
                    
                    echo "<tr>";
                    echo "<td>".$row['UserID']."</td>";
                    echo "<td>".$row['Username']."</td>";
                    echo "<td>".$row['Email']."</td>";
                    echo "<td>".$row['Type']."</td>";
                    echo "<td>".$row['Dateposted']."</td>";
                    echo "<td><button class='btn btn-info'><a class='white-text' href='Edituser.php?id=".$row['UserID']."&action=edit'>EDIT</a></button><button class='btn btn-danger btn-md'><a class='white-text' href='deleteuser.php?id=".$row['UserID']."&action=delete'>DELETE</a></button></td>";
                    echo "</tr>";
                    echo "</tr>";
                }

                ?>
            </tbody>
        </table>
        </div>
    </form>
    </div>
    <!--/.Panel 2-->
    <!--Panel 3-->
    <div class="tab-pane fade" id="panel3" role="tabpanel">
        <h5 class="my-2 h5">REGISTERED RESIDENTS</h5>
                        <form><div class="table-responsive">
        <table id="residentstable" class="stripe hover order-column row-border">
            <thead>
            <tr>
                <th>Residents ID</th>
                <th>Date Posted</th>
                <th>Lastname</th>
                <th>Firstname</th>
                <th>Middlename</th>
                <th>Address</th>
                <th>Civil Status</th>
                <th>Religion</th>
                <th>Birthdate</th>
        



                
            </tr>
            </thead>

            <tbody>
                <?php 
                while ($row = mysqli_fetch_array($result2)) {
                    
                    echo "<tr>";
                    echo "<td>".$row['ResidentsID']."</td>";
                    echo "<td>".$row['Dateposted']."</td>";
                    echo "<td>".$row['Lastname']."</td>";
                    echo "<td>".$row['Firstname']."</td>";
                    echo "<td>".$row['Middlename']."</td>";
                    echo "<td>".$row['Address']."</td>";
                    echo "<td>".$row['CivilStatus']."</td>";
                    echo "<td>".$row['Religion']."</td>";
                    echo "<td>".$row['Birthdate']."</td>";
                    

                    echo "</tr>";
                }

                ?>
            </tbody>
        </table>
        </div>
    </form>
    </div>
    <!--/.Panel 3-->
</div>
            </div>
        </section>
    </div>
</main>


 <?php require 'footer.php';?>  