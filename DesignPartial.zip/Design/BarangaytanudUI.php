
<?php require 'header4admin.php';?>

    <!--Main layout-->
    <main>

        <section class="card card-cascade">

                    <!--Grid row-->
                    <div class="row">
                    
                    <!--Grid column-->
                    <div class="col-md-12" style=" height: 500px;">
                        <!--Panel Header-->
                        <div class="view py-3 gradient-card-header" style="background-color: #3f5c80 ; font-family: Century Gothic ; font-size: 20px; text-align: left">
                            <div class="row">
                                <div class="col-md-8">
                                    <i class="fa fa-folder-open"></i>
                            ADD BARANGAY TANUD
                           
                            
                                </div>
                                <div class="col-md-4">
                                    <a href="#" class="btn-floating btn-small blue" style="float: right" ripple-radius><i class="fa fa-plus"></i></a>
                                    <a href="finalAdminPanel.php" class="btn-floating btn-small blue" style="float: right" ripple-radius><i class="fa fa-backward"></i></a>
                                 </div>
                            </div>
                            

                           
                            

                        </div>
                        <!--/Panel Header-->

                        <!--Panel content-->
                        <div class="card-body">

                            <!--Grid row-->
                            <div class="row">

                                
                                

                        </div>
                        <!--Panel content-->
                    
                    
                    </div>
                    <!--Grid column-->
                    
                    
                    
                    </div>
                    <!--Grid row-->

                </section>
                <!--Section: Main panel-->
    </main>
    <!--Main layout-->

    
   
    

 <?php require 'footer.php';?>  
