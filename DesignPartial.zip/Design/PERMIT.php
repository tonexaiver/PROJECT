<?php include 'headerstaff.php'; ?>
<main>
	<div class="container-fluid">
		<section>
			<div class="row">
				<div class="col-md">
					<h5 class="my-2 h5 text-center">REGISTERED USERS</h5>
                                  <form><div class="table-responsive">
        <table id="userstable" class="table stripe hover order-column row-border">
            <thead>
            <tr>
                <th>UserID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Type</th>
                <th>DatePosted</th>
                
            </tr>
            </thead>

            <tbody>
                <?php 
                while ($row = mysqli_fetch_array($result1)) {
                    
                    echo "<tr>";
                    echo "<td>".$row['UserID']."</td>";
                    echo "<td>".$row['Username']."</td>";
                    echo "<td>".$row['Email']."</td>";
                    echo "<td>".$row['Type']."</td>";
                    echo "<td>".$row['Dateposted']."</td>";
                    echo "</tr>";
                }

                ?>
            </tbody>
        </table>
        </div>
    </form>
				</div>
			</div>
		</section>
	</div>
</main>
<?php include 'footer.php';?>
