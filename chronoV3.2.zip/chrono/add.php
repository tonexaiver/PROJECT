<?php 

$fn=$_POST['ps'];
$un=$_POST['un'];
$ps=$_POST['ps'];
	
	if(empty($fn)||empty($un)||empty($ps)){
		echo "<script>alert('Please Fill out all empty Fields');window.location.href='register.php';</script>"	;
	}
	else
	{
		$con = mysqli_connect('localhost','root','','dataneil');

		$query = "INSERT INTO tableneil(fullname,username,password) VALUES ('$fn','$un','$ps');";

		if (mysqli_query($con,$query)){

			echo "<script>alert('Successfully Added');window.location.href='profile.php';</script>";
		}
		else
		{
			echo "<script>alert('Registration Errors.!! Check your entry for Errors.!!');</script>";
		}
	}

 ?>