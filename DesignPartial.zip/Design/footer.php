<!DOCTYPE html>

    <footer class="page-footer center-on-small-only">

        <!--Copyright-->
        <div class="footer-copyright">
            <div class="">
                © 2018 Copyright:
                <a href="#"> Group 9 </a>

            </div>
        </div>
        <!--/.Copyright-->

    </footer>



<script type="text/javascript" src="jquery/jquery.js"></script>
<script type="text/javascript" src="popper/popper.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="jquery/mdb.js"></script>
<script type="text/javascript" src="dataTables/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="mdl/material.min.js"></script>
<script type="text/javascript" src="jquery/compiled.min.js"></script>


 <script>
          new WOW().init();
        // SideNav Initialization
        $(".button-collapse").sideNav();

        $( ".wow" ).addClass( "fadeInUp" );
        $( ".wow" ).addClass( "fadeInRight" );
        $( ".wow" ).addClass( "fadeInLeft" );
        $( ".wow" ).addClass( "fadeInDown" );
        $( ".wow" ).addClass( "fadeInDownBig" );
        $( ".wow" ).addClass( "fadeIn" );
        $( ".wow" ).addClass( "flipInY" );

     function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
       
function logout() {
    session_start();
            session_destroy();
            header("location: logini.php");
}
    function displaydate() {
    var date1 = new Date();

    document.getElementById('date').value = date1;
}
window.onload = function() {
  var month = new Array("January", "February", "March", "April", "May", "June", "July",    "August", "September", "October", "November", "December");
  var today = new Date();
  var dd = today.getDate();
  var mm = today.getMonth();
  var currentMonth = month[mm];
  var yyyy = today.getFullYear();
  today = currentMonth + ' ' + dd + ', ' + yyyy;
 document.getElementById('test').innerHTML = today;
}

        // Material Select Initialization
    $(document).ready(function () {
            $('.mdb-select').material_select();
            });

         $("#fpass").click(function(){
            $("#logindiv").hide();
                });
            $("#show").click(function(){
                $("p").show();
               });

        // Data Picker Initialization
        

        $('.datepicker').pickadate({
          // `true` defaults to 10.
          selectYears: 200
        })

        // Tooltip Initialization
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        });
        
    </script>
    <script src="tables/jquery.dataTables.min.js"></script>
   <script type="text/javascript">
        $(function(){
            $("#stafftable").DataTable();
            $("#userstable").DataTable();
            $("#residentstable").DataTable();

} );

</script>

</body>
</html>