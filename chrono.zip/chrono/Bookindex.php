<?php 
session_start();
if (!isset($_SESSION['username'])) {
    header("location: index.php");
}
$con = mysqli_connect('localhost','root','','dataneil');
$query = "select * from books;";
$result = mysqli_query($con,$query);

?> 
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Dashboard Template for Bootstrap</title>
        <!-- Bootstrap core CSS -->
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="dashboard.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
        <style type="text/css">
            .modal-dialog {
            width: 750px;
            margin: auto;
            }

</style>
    </head>
    <body>
        <div class="container">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="dashboard.php">Home</a>
                    </div>
                    <div id="navbar" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
</li>
                            <li>
                                <a href="#">Settings</a>
                            </li>
                            <li>
                                <a href="home">Profile</a>
                            </li>
                            <li>
                                <a href="logout.php">Logout</a>
                            </li>
                        </ul>
                        <form class="navbar-form navbar-right">
</form>
                    </div>
                </div>
            </nav>
            <div class="container-fluid">
                <div class="row"></div>
                <div class="row">
                    <div class="row">
                        <div class="row"></div>
                    </div>
                </div>
            </div>
            <!-- Bootstrap core JavaScript
    ================================================== -->
            <!-- Placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="bootstrap/js/bootstrap.min.js"></script>
            <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
            <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
            <div class="container">
                <form role="form" action="bookadd.php" method="POST"> 
                    <div class="form-group"> 
                        <label class="control-label" >Book ID</label>                         
                        <input type="text" class="form-control"  placeholder=""> 
                    </div>
                    <div class="form-group"> 
                        <label class="control-label" >Book Title</label>                         
                        <input type="text" class="form-control"  placeholder=""> 
                    </div>
                    <div class="form-group"> 
                        <label class="control-label" >Borrower Full Name</label>                         
                        <input type="text" class="form-control"  placeholder=""> 
                    </div>
                    <div class="form-group"> 
                        <label class="control-label btn-default" >Date Borrowed</label>                         
                        <input class="form-control"  value="<?php 
                        echo date('l-H:i:s-m-d-y')
                     ?> " disabled>
                    </div>
                    <div class="form-group"> 
                        <label class="control-label" >Librarian Engarge</label>                         
                        <input type="text" class="form-control"  placeholder=""> 
                    </div>  
                    <div class="container text-center clear-fix">
                        <button type="submit" name="submit" id="btnSubmit" class="btn btn-default">Add New</button>
                        <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal1">View Added</button>
                    </div>                   
                </form>
            </div>
            
            <div class="container">
                <div class="modal fade pg-show-modal" id="modal1" tabindex="-1" role="dialog" aria-hidden="true"> 
                    <div class="modal-dialog"> 
                        <div class="modal-content modal-dialog modal-lg"> 
                            <div class="modal-header"> 
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>                                 
                                <h4 class="modal-title text-center ">Modal title</h4> 
                            </div>                             
                            <div class="modal-body">
                                <table class="table"> 
                                    <thead> 
                                        <tr> 
                                            <th>Book ID</th> 
                                            <th>Book Title</th> 
                                            <th>Borrower Full Name</th> 
                                            <th>Date Borrowed</th>
                                            <th>Encharge Librarian</th> 
                                        </tr>                                         
                                    </thead>                                     
                                    <tbody> 
                                        <?php 
                                                while($row = mysqli_fetch_array($result))
                                                {
                                                    echo "<tr>";
                                                    echo "<td>".$row['id']."</td>";
                                                    echo "<td>".$row['fullname']."</td>";
                                                    echo "<td>".$row['username']."</td>";
                                                    echo "<td>".$row['password']."</td>";
                                                    echo "<td><a href='edit.php?id=".$row['id']."&action=edit'>EDIT</a>.<a href='delete.php?id=".$row['id']."&action=delete'>DELETE</a></td>";
                                                    echo "</tr>";
                                                }
                                                

                                                ?>
                                    </tbody>
                                </table>                                 
                            </div>                             
                            <div class="modal-footer"> 
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>                                 
                                <button type="button" class="btn btn-primary">Save changes</button>                                 
                            </div>                             
                        </div>                         
                    </div>                     
                </div>
            </div>
    </body>
</html>
