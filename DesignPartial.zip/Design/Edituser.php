<?php

$id=$_GET['id'];

$con=mysqli_connect('localhost','root','','adweb');
//create query
$query = "select * from tbluser where UserID=".$id;
//execute query, save result to $result variable
$result = mysqli_query($con, $query);

$row = mysqli_fetch_array($result);

?>
<?php include 'headerstaff.php'; ?>
<main>
	<div class="container">
		<section>
			<div class="row">
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<div class="card card-cascade narrower">

        <!--Card image-->
        	<div class="view gradient-card-header purple-gradient">
            	<h4>Update User Form</h4>
   
        </div>

        <div class="card-body">
        	<form method="POST" action="updateUser.php">
        		<div class="md-form form-sm">
                   
                        <input type="hidden" name="id" value = "<?php echo $row['UserID']; ?>">
                        </div>
                
                    <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form34" class="form-control" name="username" value = "<?php echo $row['Username']; ?>">
                        <label for="form34">Username</label>
                    </div>
                     <div class="md-form form-sm">
                        <i class="fa fa-address-book prefix"></i>
                        <input type="text" id="form35" class="form-control" name="email" value = "<?php echo $row['Email']; ?>">
                        <label for="form35">Email</label>
                    </div>
                     <div class="md-form form-sm">
                        <i class="fa fa-address-book prefix"></i>
                        <input type="password" id="form36" class="form-control" name="password">
                        <label for="form36">password</label>
                    </div>

                     <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form37" class="form-control" name="conpass">
                        <label for="form37">Confirm Password</label>
                    </div>
                     <div class="md-form form-sm">
                        <select id="form38" class="mdb-select colorful-select dropdown-primary" name="type"  value = "<?php echo $row['Type']; ?>">
                        <option value="#">Select type</option>
                            <option value="Admin">Admin</option>
                            <option value="User">User</option>
                            
                        </select>
                        <label for="form38">User type</label>
                    </div>

                    <div class="md-form form-sm">
                        <i class="fa fa-calendar prefix"></i>
                        <input type="text" class="form-control datepicker" name="dateposted"  value = "<?php echo $row['Dateposted']; ?>">
                        <label for="date-picker">Date</label>        
                    </div>
    
                    <div class="text-center mt-2">
                        <button class="btn btn-info" type="submit" name="btnUpdate">UPDATE<i class="fa fa-sign-in ml-1"></i></button>
                    </div>
    
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
</section>
</div>
</main>
 <?php require 'footer.php';?> 