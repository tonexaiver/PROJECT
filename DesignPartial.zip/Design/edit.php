<?php

$id=$_GET['id'];

$con=mysqli_connect('localhost','root','','adweb');
//create query
$query = "select * from tblrEsidents where ResidentsID=".$id;
//execute query, save result to $result variable
$result = mysqli_query($con, $query);

$row = mysqli_fetch_array($result);

?>
<?php include 'headerstaff.php'; ?>
<main>
	<div class="container">
		<section>
			<div class="row">
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<div class="card card-cascade narrower">

        <!--Card image-->
        	<div class="view gradient-card-header purple-gradient">
            	<h4>Update RESIDENTS Form</h4>
   
        </div>
        <!--/Card image-->

        <!--Card content-->
        <div class="card-body">
        		<form action="updateResident.php" method="post" >
        				<div class="md-form form-sm">
                   
                        <input type="hidden" name="id" value = "<?php echo $row['ResidentsID']; ?>">
                        </div>
                
        
                      <div class="md-form form-sm">
                        <i class="fa fa-calendar prefix"></i>
                        <input type="text" class="form-control datepicker" name="dateposted2" value = "<?php echo $row['Dateposted']; ?>">
                        <label for="date-picker">Date</label>        
                    </div>

                <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form29" class="form-control" name="lastname" value = "<?php echo $row['Lastname']; ?>">
                        <label for="form29">Lastname</label>
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="firstname" value = "<?php echo $row['Firstname']; ?>">
                        <label for="form30">Firstname</label>
                    </div>
                     <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="middlename" value = "<?php echo $row['Middlename']; ?>">
                        <label for="form30">Middlename</label>
                    </div>
                       <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="address" value = "<?php echo $row['Address']; ?>">
                        <label for="form30">Address</label>
                    </div>
                     <div class="md-form form-sm">
                        <select class="mdb-select colorful-select dropdown-primary" name="civilstatus" value = "<?php echo $row['CivilStatus']; ?>">
                        <option value="#">Select Status</option>
                            <option value="Single">Single</option>
                            <option value="Married">Married</option>
                            <option value="Divorced">Divorced</option>
                            <option value="Widowed">Widowed</option>
                        </select>
                        <label for="form33">Civil status</label>
                    </div>
                      <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="Religion" value = "<?php echo $row['Religion']; ?>">
                        <label for="form30">Religion</label>
                    </div>

                       <div class="md-form form-sm">
                        <i class="fa fa-calendar prefix"></i>
                        <input type="text" class="form-control datepicker" name="birthdate" value = "<?php echo $row['Birthdate']; ?>">
                        <label for="date-picker">Birthdate</label>        
                    </div>
                     
                    <button class="btn btn-teal" type="submit" name="btnUpdate">UPDATE<i class="fa fa-sign-in ml-1"></i></button>
    			</form>


           

        </div>
        <!--/.Card content-->

    </div>
</div>
					
		
	<div class="col-md-2"></div>
			</div>
		</section>
	</div>
</main>
	
<?php include 'footer.php';?>



