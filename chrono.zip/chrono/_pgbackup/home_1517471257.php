<?php 
session_start();
if (!isset($_SESSION['username'])) {
    header("location: index.php");
}
$con = mysqli_connect('localhost','root','','dataneil');
$query = "select * from tableneil;";
$result = mysqli_query($con,$query);

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Starter Template for Bootstrap</title>
        <!-- Bootstrap core CSS -->
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="starter-template.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href=".../css/style.css">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    </head>
    <body>
        <div class="container">
            <nav class="navbar navbar-inverse">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#" id="home1">Home</a>
                    </div>
                    <div id="navbar" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav">
                            <li class="active">
                                <a href="manage.php">Manage</a>
                            </li>
                            <li>
                                <a href="reports.php">Report</a>
                            </li>
                            <li>
                                <a href="profile.php">Profile</a>
                            </li>
                            <li>
                                <a href="logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </nav>
            <div class="container">
</div>
            <div class="row"></div>
        </div>
        <div class="container pg-empty-placeholder">
            <div class="container">
                <form> 
                    <div class="table-responsive"> 
                        <div class="container">
                            <a href='register.php' class="btn btn-success clear-fix btn-lg">Add New</a>
                        </div>
                        <input class="btn-default clear-fix" type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names..">
                        <table class="table table-grey table-hover" id="myTable"> 
                            <tr> 
                                <th scope="row">Id</th> 
                                <th scope="row">FullName</th> 
                                <th scope="row">Username</th> 
                                <th scope="row">password</th> 
                                <th scope="row" class="text-center">Time Log</th> 
                                <th scope="row" class="text-right">Action</th> 
                            </tr>                             
                            <tr> 
                                <?php 
                                                while($row = mysqli_fetch_array($result))
                                                {
                                                    echo "<tr>";
                                                    echo "<td>".$row['id']."</td>";
                                                    echo "<td>".$row['fullname']."</td>";
                                                    echo "<td>".$row['username']."</td>";
                                                    echo "<td>".$row['password']."</td>";
                                                    echo "<td>".$row['log']."</td>";
                                                    echo "<td>".$row['']."</td>";
                                                    echo "<td><a href='edit.php?id=".$row['id']."&action=edit'>EDIT</a>.<a href='delete.php?id=".$row['id']."&action=delete'>DELETE</a></td>";
                                                    echo "</tr>";
                                                }
                                                

                                                ?> 
                            </tr>                             
                            <hr> 
                        </table>                         
                    </div>                     
                </form>                 
            </div>             
        </div>
        <!-- /.container -->
        <!-- Bootstrap core JavaScript
    ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
        <script src="css/style.js"></script>
    </body>
</html>
