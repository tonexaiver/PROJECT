<?php

$bi=$_GET['bookid'];
	$con=mysqli_connect('localhost','root','','dataneil');
	//create query
	$query = "delete from books where bookid=".$bi;
	//execute query
	if(mysqli_query($con, $query))
	{
		echo "<script>alert('User Successfully Deleted...');window.location.href='books.php'</script>";
	}
	else
	{
		echo "<script>alert('Sorry.!!');window.location.href='books.php'</script>";
	}

?>
