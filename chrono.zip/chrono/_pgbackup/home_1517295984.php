<?php 
session_start();
if (!isset($_SESSION['username'])) {
	header("location: index.php");
}
$con = mysqli_connect('localhost','root','','dataneil');
$query = "select * from tableneil;";
$result = mysqli_query($con,$query);

?> 
<html> 
    <head> 
        <title>Home</title>         
        <link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.css"> 
        <link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css"> 
        <style type="text/css"> 
            body{
            background-color: skyblue;
            }
            .card-header{
            background-color: gray; 
            }
            .card-body{
            background-color: ;
            }
            #btnSubmit, #btns{
            border-radius: 100px;	
            text-decoration: none
            }
            b{
            color:black;
            }
            .form-control{
            border-top: none;
            border-right: none;
            border-left: none;
            }
            .card-footer{
            background-color: transparent;
            }
            .tds{
            }
</style>         
    </head>     
    <body> 
        <div class="container"> 
            <br>
            <div class="card-header">
                <h1>Beench Dealer</h1>
            </div>
            <div class="container"> 
                <div class="row"> 
                    <div class="col-md-3">
                        <br>
                        <div class="card-header">
                            <center>
                                <h5>Info</h5>
                            </center>
                        </div>
                        <button type="button" class="btn btn-info col-md-12">Products</button>
                        <button type="button" class="btn btn-info col-md-12">Cart</button>
                        <button type="button" class="btn btn-info col-md-12">View Catalog</button>
                        <hr>
                        <div class="card-header">
                            <center>
                                <h5>earl</h5>
                            </center>
                        </div>
                    </div>                     
                    <div class="col-md-6">
                        <br> 
                        <div class="card"> 
                            <div class="card-header">
                                <center>
                                    <h5>PRODUCTS LIST</h5>
                                </center>
                            </div>                             
                            <div class="card-body visible-print"> 
                                <center> 
                                    <form> 
                                        <div class="table-responsive"> 
                                            <table class="table table-grey table-hover"> 
                                                <tr> 
                                                    <th>Id</th> 
                                                    <th>FullName</th> 
                                                    <th>Username</th> 
                                                    <th>password</th> 
                                                    <th>Action</th> 
                                                </tr>                                                 
                                                <tr> 
                                                    <?php 
												while($row = mysqli_fetch_array($result))
												{
													echo "<tr>";
													echo "<td>".$row['id']."</td>";
													echo "<td>".$row['fullname']."</td>";
													echo "<td>".$row['username']."</td>";
													echo "<td>".$row['password']."</td>";
													echo "<td><a href='edit.php?id=".$row['id']."&action=edit'>EDIT</a>.<a href='delete.php?id=".$row['id']."&action=delete'>DELETE</a></td>";
													echo "</tr>";
												}
												

												?> 
                                                </tr>                                                 
                                                <tr> 
                                                    <td class=".tds">
                                                        <a href='register.php'>Add New
                                                    </td>                                                     
                                                    <td class=".tds">
                                                        <a href="logout.php">logout</a>
                                                    </td>                                                     
                                                </tr>                                                 
                                            </table>                                             
                                        </div>                                         
                                    </form>                                     
                                </center>
                                <ul class="pagination"> 
                                    <li>
                                        <a href="#">&laquo;</a>
                                    </li>                                     
                                    <li class="active">
                                        <a href="#">1 <span class="sr-only">(current)</span></a>
                                    </li>                                     
                                    <li>
                                        <a href="#">2</a>
                                    </li>                                     
                                    <li>
                                        <a href="#">3</a>
                                    </li>                                     
                                    <li>
                                        <a href="#">&raquo;</a>
                                    </li>                                     
                                </ul>                                 
                            </div>                             
                        </div>                         
                    </div>                     
                    <div class="col-md-3"> 
</div>                     
                </div>                 
            </div>             
        </div>         
    </body>     
</html>