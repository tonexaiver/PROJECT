<div class="heads">
<?php include 'header4staff.php'; ?>
</div>
<?php 
$con = mysqli_connect('localhost','root','','fmsg9');
$query = "select * from ctransaction;";
$result = mysqli_query($con,$query);

?>
<style type="text/css">
	#btnprint2{
		float: right;
	}
 </style>
<main>
	<section>
		<div class="row">
			<div class="col-md-3">
                <div class="col-md-4"><a href="ClerancesUI.php" class="btn-floating btn-small blue animated fadeInDownBig" style="float: left" ripple-radius><i class="fa fa-backward"></i></a></div>
			</div>
			<div class="col-md-6">
				

                <div class="col-md-12 animated fadeInLeft" >
                <form action="Certificationcode.php" class="form1" method="POST">
                	<div class="row">
                	<div class="col-md-8">
                    	<div class="md-form ">
                            <input type="text" name="fullname" id="fullname" class="form-control" required>
                            <label for="name"  >Full name</label>
                        </div>
                    </div>
                    <div class="col-md-4">
                            <div class="md-form ">
                                <input type="number" name="age" class="form-control" required>
                                <label>Age</label>
                            </div>
                        </div>
                	</div>
                    <div class="row">
                    	<div class="col-md-12" >
                            <div class="md-form">
                                <select class="mdb-select" name="purok" required>
                                    <option value="" disabled selected>Choose Purok</option>
                                    <option value="Purok 1">Purok 1</option>
                                    <option value="Purok 2">Purok 2</option>
                                    <option value="Purok 3">Purok 3</option>
                                    <option value="Purok 4">Purok 4</option>
                                    <option value="Purok 5">Purok 5</option>
                                    <option value="Purok 6">Purok 6</option>
                                    <option value="Purok 7">Purok 7</option>
                                    <option value="Purok 8">Purok 8</option>
                                </select>
                                <label>Clearance for :</label>
                        	</div>
                        </div>
                        
                    </div>
                    <div class="row">
                    <div class="col-md-4">
                            <div class="md-form ">
                                <input type="number" name="day" class="form-control" placeholder="00" required>
                                <label>Current Day</label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="md-form ">
                                <input type="number" name="month" class="form-control" placeholder="00" required>
                                <label>Current month</label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="md-form ">
                                <input type="number" name="year" class="form-control" placeholder="0000" required>
                                <label for="name">Current Year</label>
                            </div>
                        </div>
                        </div>
                	
                    <div class="row">
                    <div class="col-md-12">
                    	<div class="md-form ">
                            <input type="text" name="purpose" class="form-control" required>
                            <label for="name">Purpose</label>
                        </div>
                    </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="md-form ">
                                <input type="number" id="qty" name="coh"  class="form-control" required>
                                <label for="name">Cash on hand :</label>
                        	</div>
                        </div>
                        <div class="col-md 4">
                            <div class="md-form ">
                                <input type="text" id="result" name="change" placeholder="0"   class="form-control" required>
                                <label for="name">Change :</label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="md-form ">
                                <input type="number"
                                id="amount" name="amount" value="30" class="form-control" required>
                                <label for="name">Amount to Paid :</label>
                            </div>
                        </div>
                        
                    </div>
                 
                    
                	
                    <!-- <button type="button"  class="btn btn-purple" id="s" style="float: right" onclick="print()">
					    Print
					</button> -->
					        <!-- Button trigger modal -->    

					<button type="submit" name="submit" id="submit" class="btn btn-indigo" style="float: right">
					    Add<i class="fa fa-paper-plane-o ml-2"></i>
					</button>
					<a href="Certificateshow.php" id="btnprint2" style="color:white;"><button"  class="btn btn-orange">
						Show<i class="fa fa-hand-pointer-o ml-2"></i>
					</button></a>
					  
					
					
					
					</form>  
				</div>
				

                                    			
			
			<div class="col-md-3">
			</div>
		</div>
	</section>
</main>
<div class="foot">
	<?php include 'footer.php';?>
</div>
