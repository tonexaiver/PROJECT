<?php 
$fullname=$_POST['fullname'];
$type=$_POST['type'];
$dates=$_POST['dates'];
$orno=$_POST['orno'];
$Cashonhand=$_POST['Cashonhand'];
$change=$_POST['change'];
$amount=$_POST['amount'];




	$con =mysqli_connect('localhost','root','','fmsg9');
	$query = "INSERT INTO tblbpermit (Fullname,BusinessType,Date,Orno,Amount) VALUES ('$fullname','$type','$dates','$orno','$amount');";

	if (mysqli_query($con,$query)) {
		
		echo "<script>alert('successfully added');window.location.href='BpermitUI.php';</script>";
	}
	else
		{
			echo "<script>alert('Check your entry for errors!');</script>";
		}





 ?>