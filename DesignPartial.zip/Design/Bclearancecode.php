<?php 
$fullname=$_POST['fullname'];
$ddb=$_POST['ddb'];
$orno=$_POST['orno'];
$barangay=$_POST['barangay'];
$barangayad=$_POST['barangayad'];
$coh=$_POST['coh'];
$dates=$_POST['dates'];
$result=$_POST['result'];
$amount=$_POST['amount'];



	$con =mysqli_connect('localhost','root','','fmsg9');
	$query = "INSERT INTO ctransaction(fullname,purpose,orno,barangay,barangayad,dates,amount) VALUES('$fullname','$ddb','$orno','$barangay','$barangayad','$dates','$amount');";

	if (mysqli_query($con,$query)) {
		
		echo "<script>alert('successfully added');window.location.href='BclearanceUI.php';</script>";
	}
	else
		{
			echo "<script>alert('Check your entry for errors!');</script>";
		}





 ?>