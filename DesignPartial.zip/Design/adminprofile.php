<?php require 'header.php';?>
    <main>
    <section> <div class="container-fluid"><div class="row">

    <!-- Grid column -->
    <div class="col-md-10 col-lg-9 col-xl-6 mb-r">
        
        <!--Panel-->
        <div class="card card-body mb-3">
            <div class="media d-block d-md-flex">
                <img class="d-flex avatar-2 mb-md-0 mb-3 mx-auto" src="https://mdbootstrap.com/img/Photos/Avatars/img (31).jpg" alt="Generic placeholder image">
                <div class="media-body text-center text-md-left ml-md-3 ml-0">
                    <p>Mga informations ni sa admin</p>
                    <button type="button" class="btn btn-primary btn-md">Read more</button>
                </div>
            </div>
        </div>
        <!--/.Panel-->

         <div class="card card-body mb-3">
            <div class="media d-block d-md-flex">
                <div class="media-body pr-md-3 pr-0 text-center text-md-left">
                    <p>para secret ni</p>
                </div>
            </div>
        </div>

       

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-md-10 col-lg-9 col-xl-6">

        <!--Panel-->
        <div class="card mb-3">
            <div class="card-body">
            <h4 class="card-header deep-orange white-text text-uppercase text-center">Personal Information</h4>
                <div class="media d-block d-md-flex mt-md-0 mt-4 mb-4">
                    <div class="media-body ml-md-3 ml-0">
                        <form>
                            <!-- Grid row -->
                                <div class="row">

                                    <!-- Grid column -->
                                    <div class="col-lg-4">

                                        <div class="md-form form-sm">
                                            <input id="form12" class="form-control" type="text">
                                            <label for="form12" class="">Lastname</label>
                                        </div>

                                    </div>
                                    <!-- Grid column -->

                                    <!-- Grid column -->
                                    <div class="col-lg-4">

                                        <div class="md-form form-sm">
                                            <input id="form3" class="form-control" type="text">
                                            <label for="form3" class="">Firstname</label>
                                        </div>

                                    </div>
                                    <!-- Grid column -->

                                    <!-- Grid column -->
                                    <div class="col-lg-4">

                                        <div class="md-form form-sm">
                                            <input id="form4" class="form-control" disabled="disabled" type="text">
                                            <label for="form4" class="disabled">Company</label>
                                        </div>

                                    </div>
                                    <!-- Grid column -->


                                </div>
                                <!-- Grid row -->

    

                                <!-- Grid row -->
                                <div class="row">

                                    <!-- Grid column -->
                                    <div class="col-md-12">

                                        <div class="md-form form-sm">
                                            <input id="form6" class="form-control" type="text">
                                            <label for="form6" class="">Address</label>
                                        </div>

                                    </div>
                                    <!-- Grid column -->

                                </div>
                                <!-- Grid row -->


                                <!-- Grid row -->
                                <div class="row">

                                    <!-- Grid column -->
                                    <div class="col-lg-4 col-md-12">

                                        <div class="md-form form-sm">
                                            <input id="form7" class="form-control" type="text">
                                            <label for="form7" class="">City</label>
                                        </div>

                                    </div>
                                    <!-- Grid column -->

                                    <!-- Grid column -->
                                    <div class="col-lg-4 col-md-6">

                                        <div class="md-form form-sm">
                                            <input id="form8" class="form-control" type="text">
                                            <label for="form8" class="">Country</label>
                                        </div>

                                    </div>
                                    <!-- Grid column -->

                                    <!-- Grid column -->
                                    <div class="col-lg-4 col-md-6">

                                        <div class="md-form form-sm">
                                            <input id="form9" class="form-control" type="text">
                                            <label for="form9" class="">Postal Code</label>
                                        </div>

                                    </div>
                                    <!-- Grid column -->

                                </div>
                                <!-- Grid row -->

                        <div class="text-center text-md-left">
                            <button type="button" class="btn btn-indigo btn-rounded btn-md">Update</button>
                        </div>
                    </div>
                </div>
                </form>


                <h4 class="card-header deep-orange white-text text-uppercase text-center">Account Information</h4>
                <div class="media d-block d-md-flex">

                    <div class="media-body mr-md-3 mr-0">
                         
                                <form>
                            <!-- Grid row -->
                                <div class="row">

                                    <!-- Grid column -->
                                    <div class="col-lg-6">

                                        <div class="md-form form-sm">
                                            <input id="form12" class="form-control" type="text">
                                            <label for="form12" class="">Email</label>
                                        </div>

                                    </div>
                                    <!-- Grid column -->

                                    <!-- Grid column -->
                                    <div class="col-lg-6">

                                        <div class="md-form form-sm">
                                            <input id="form3" class="form-control" type="text">
                                            <label for="form3" class="">Username</label>
                                        </div>

                                    </div>
                                    <!-- Grid column -->


                                </div>

                                <div class="row">

                                    <!-- Grid column -->
                                    <div class="col-lg-6">

                                        <div class="md-form form-sm">
                                            <input id="form12" class="form-control" type="text">
                                            <label for="form12" class="">Password</label>
                                        </div>

                                    </div>
                                    <!-- Grid column -->

                                    <!-- Grid column -->
                                    <div class="col-lg-6">

                                        <div class="md-form form-sm">
                                            <input id="form3" class="form-control" type="text">
                                            <label for="form3" class="">Confirm Password</label>
                                        </div>

                                    </div>
                                    <!-- Grid column -->

                                    </div>
                             

                        <div class="text-center text-md-left">
                            <button type="button" class="btn btn-indigo btn-rounded btn-md">Update</button>
                        </div>
                    </div>
                      
                            </form>
                </div>
            </div>
        </div>
        <!--/.Panel-->

    </div>
    <!-- Grid column -->

</div>
        
            <!--Section: Accordion-->
            <section class="mb-5">

            </section>
            <!--Section: Accordion-->

        </div>
        </div>
        </section>
    </main>
    <!--Main layout-->

 <?php require 'footer.php';?> 
