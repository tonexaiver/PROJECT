<?php 

if(isset($_POST['btnlogin']))
{
	$un = $_POST['username'];
	$ps = $_POST['password'];
	$tl = $_POST['timelog'];

		if(empty($un)||empty($ps)){
			
			echo "<script>alert('Please Fill out all empty Fields...');window.location.href='index.php';</script>"	;
		}
		else
		{
			$con = mysqli_connect('localhost','root','','library_system');
			$query = "SELECT * FROM tableneil where username='$un' AND password='$ps' AND timelog='$tl' ";
			$result = mysqli_query($con,$query);
			$num_rows = mysqli_num_rows($result);

			if($num_rows >0){
				session_start();
				$_SESSION['username'] = $un;
				echo "<script>alert('Welcome...');location.href='dashboard.php'</script>";
			}
			else
			{
				echo "<script>alert('Error...');location.href='index.php'</script>";
			}
		}
}



 ?>