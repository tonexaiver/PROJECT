<?php

$id=$_GET['id'];
	$con=mysqli_connect('localhost','root','','library_system');
	//create query
	$query = "delete from tableneil where id=".$id;
	//execute query
	if(mysqli_query($con, $query))
	{
		echo "<script>alert('User Successfully Deleted...');window.location.href='home.php'</script>";
	}
	else
	{
		echo "<script>alert('Sorry.!!');window.location.href='home.php'</script>";
	}

?>
