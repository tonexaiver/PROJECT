<?php include 'headerstaff.php'; ?>
<main style="height: 100%">
    <div class="container">
	<section>
            <div class="row" >

                    <div class="col-xl-6 col-md-6 mb-r">

                        <!--Card Purple-->
                        <div class="card classic-admin-card red lighten-2  wow fadeInUp" data-wow-delay="0.3s">
                            <div class="card-body">
                                <div class="pull-right">
                                    <i class="fa fa-users"></i>
                                </div>
                                <h5 class="white-text">RESIDENTS</h5>
                            </div>
                            <div>
                                
                                <p class="display-1 mb-2 wow fadeInDown white-text" data-wow-delay="0.3s" style="text-align: center; font-size: 50px;">RESIDENT</p>
                            </div>
                            <div class="text-center mt-2 mb-3">
                            <button class="btn aqua-gradient btn-lg" type="submit" data-toggle="modal" data-target="#residentsModal">Add<i class="fa fa-sign-in ml-1"></i></button>
                            
                            </div>
                        </div>
                        <!--/.Card Purple-->

                    </div>

                         <div class="col-xl-6 col-md-6 mb-r">

                        <!--Card Purple-->
                        <div class="card classic-admin-card blue lighten-2  wow fadeInLeft" data-wow-delay="0.3s">
                            <div class="card-body">
                                <div class="pull-right">
                                    <i class="fa fa-users"></i>
                                </div>
                                <h5 class="white-text">CERTIFICATE OF INDIGENCY ISSUANCE</h5>
                            </div>
                            <div>
                                <h4 class="display-1 mb-2 wow fadeInDown white-text" data-wow-delay="0.3s" style="text-align: center; font-size: 50px;">COI</h4>
                            </div>
                            <div class="text-center mt-2 mb-3">
                            <button class="btn peach-gradient btn-lg" type="submit" data-toggle="modal" data-target="#indigencyModal">Issue<i class="fa fa-sign-in ml-1"></i></button>
                            
                            </div>
                        </div>
                        <!--/.Card Purple-->

                    </div>
                        <!--/.Card-->
                         <div class="col-xl-6 col-md-6 mb-r">

                        <!--Card Purple-->
                        <div class="card classic-admin-card orange lighten-2  wow fadeInRight" data-wow-delay="0.3s">
                            <div class="card-body">
                                <div class="pull-right">
                                    <i class="fa fa-users"></i>
                                </div>
                                <h5 class="white-text">BARANGGAY CLEARANCE</h5>
                            </div>
                            <div>
                                <h4 class="display-1 mb-2 wow fadeInDown white-text" data-wow-delay="0.3s" style="text-align: center; font-size: 50px;">CLEARANCE</h4>
                            </div>
                            <div class="text-center mt-2 mb-3">
                            <button class="btn purple-gradient btn-lg" type="submit" data-toggle="modal" data-target="#clearanceModal">Issue<i class="fa fa-sign-in ml-1"></i></button>
                           
                            </div>
                        </div>
                        <!--/.Card Purple-->

                    </div>

                     <div class="col-xl-6 col-md-6 mb-r">

                        <!--Card Purple-->
                        <div class="card classic-admin-card pink lighten-2  wow fadeInDown" data-wow-delay="0.3s">
                            <div class="card-body">
                                <div class="pull-right">
                                    <i class="fa fa-users"></i>
                                </div>
                                <h5 class="white-text">BUSINESS PERMIT</h5>
                            </div>
                            <div>
                                <h4 class="display-1 mb-2 wow fadeInDown white-text" data-wow-delay="0.3s" style="text-align: center; font-size: 50px;">PERMIT</h4>
                            </div>
                            <div class="text-center mt-2 mb-3">
                            <button class="btn blue-gradient btn-lg" type="submit" data-toggle="modal" data-target="#BRModal">Issue<i class="fa fa-sign-in ml-1"></i></button>
                            
                            </div>
                        </div>
                        <!--/.Card Purple-->

                    </div>
            </section>
            </div>

</main>

<div class="modal fade custom-scrollbar list-unstyled" id="residentsModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog cascading-modal" role="document">
            <!--Content-->
            <div class="modal-content">
    
                <!--Header-->
                <div class="modal-header teal darken-1 white-text">
                                    <h5 class="title"><i class="fa fa-user-plus"></i>Resident</h5>
                    <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <!--Body-->
                <div class="modal-body">
                <form action="addresident4staff.php" method="post" >
                      <div class="md-form form-sm">
                        <i class="fa fa-calendar prefix"></i>
                        <input type="text" class="form-control datepicker" name="dateposted2">
                        <label for="date-picker">Date</label>        
                    </div>
                <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form29" class="form-control" name="lastname">
                        <label for="form29">Lastname</label>
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="firstname">
                        <label for="form30">Firstname</label>
                    </div>
                     <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="middlename">
                        <label for="form30">Middlename</label>
                    </div>
                       <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="address">
                        <label for="form30">Address</label>
                    </div>
                     <div class="md-form form-sm">
                        <select class="mdb-select colorful-select dropdown-primary" name="civilstatus">
                        <option value="#">Select Status</option>
                            <option value="Single">Single</option>
                            <option value="Married">Married</option>
                            <option value="Divorced">Divorced</option>
                            <option value="Widowed">Widowed</option>
                        </select>
                        <label for="form33">Civil status</label>
                    </div>
                      <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="Religion">
                        <label for="form30">Religion</label>
                    </div>

                       <div class="md-form form-sm">
                        <i class="fa fa-calendar prefix"></i>
                        <input type="text" class="form-control datepicker" name="birthdate">
                        <label for="date-picker">Birthdate</label>        
                    </div>
                     
                    <button class="btn btn-teal" type="submit">Add<i class="fa fa-sign-in ml-1"></i></button>
                    <button type="button" class="btn btn-outline-elegant waves-effect ml-auto" data-dismiss="modal">Close</button>
    
                    
    
                </div>
                </form>


                
            </div>
            <!--/.Content-->
        </div>
    </div>

    <div class="modal fade custom-scrollbar list-unstyled" id="indigencyModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog cascading-modal" role="document">
            <!--Content-->
            <div class="modal-content">
    
                <!--Header-->
                <div class="modal-header teal darken-1 white-text">
                                    <h5 class="title"><i class="fa fa-user-plus"></i>Certification</h5>
                    <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <!--Body-->
                <div class="modal-body">
                <form method="POST" action="addindigency.php">
                <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form29" class="form-control" name="fullname">
                        <label for="form29">Fullname</label>
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="age">
                        <label for="form30">Age</label>
                    </div>
                    <div class="md-form form-sm">
                    <input type="text" name="purok" class="form-control">
                        <label>Purok</label>
                                  
                    </div>
                    <div class="md-form form-sm">
                    <input type="text" name="day" class="form-control">
                        <label for="date-picker">Day</label>
                                  
                    </div>
                     <div class="md-form form-sm">
                        <select class="mdb-select colorful-select dropdown-primary" name="month">
                        <option value="#">Select Month</option>
                        	<option value="January">January</option>
                        	<option value="February">February</option>
                        	<option value="March">March</option>
                        	<option value="April">April</option>
                        	<option value="May">May</option>
                        	<option value="June">June</option>
                        	<option value="July">July</option>
                        	<option value="August">August</option>
                        	<option value="September">September</option>
                        	<option value="October">October</option>
                        	<option value="November">November</option>
                        	<option value="December">December</option>

                        </select>
                        <label for="form33">Month</label>
                    </div>
                    <div class="md-form form-sm">
                        <select class="mdb-select colorful-select dropdown-primary" name="year">
                        <option value="2018">2018</option>
                        	</select>
                        <label for="form33">Year</label>
                   </div>
 					<div class="md-form form-sm">
                        <input type="text" id="form33" class="form-control" name="purpose">
                        <label for="form33">Purpose</label>
                    </div>
                    
                    
    
                    
    
                </div>
                </form>
                <!--Footer-->
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-elegant waves-effect ml-auto" data-dismiss="modal">Close</button>
                     <div class="text-center mt-2">
                        <button class="btn btn-teal" type="submit" id="btnprint" onclick="print()">Proceed<i class="fa fa-sign-in ml-1"></i></button>
                    </div>
                    
                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>


    <div class="modal fade custom-scrollbar list-unstyled" id="BRModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog cascading-modal" role="document">
            <!--Content-->
            <div class="modal-content">
    
                <!--Header-->
                <div class="modal-header teal darken-1 white-text">
                                    <h5 class="title"><i class="fa fa-user-plus"></i> BUSINESS PERMIT ISSUANCE</h5>
                    <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <!--Body-->
                <div class="modal-body">
                <form method="POST" action="addindigency.php">

                <div class="md-form form-sm">
                        <select class="mdb-select colorful-select dropdown-primary">
                        <option value="#">Select Type</option>
                        <option value="Building">New</option>
                        	<option value="Fencing">Renewal</option>
                        	
                        	</select>
                        <label>Permit type</label>
                                  
                    </div>
                <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form29" class="form-control" name="fullname">
                        <label for="form29">Fullname</label>
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="age">
                        <label for="form30">Type or Name of Business</label>
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-calendar prefix"></i>
                        <input type="text" class="form-control datepicker" name="date">
                        <label for="date-picker">Issued on</label>
                                  
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="age">
                        <label for="form30">O.R. No.</label>
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="age">
                        <label for="form30">Amount of Php</label>
                    </div>
                   
                     
                    
    
                    
    
                </div>
                </form>
                <!--Footer-->
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-elegant waves-effect ml-auto" data-dismiss="modal">Close</button>


                    <div class="text-center mt-2">
                        <button class="btn btn-teal" type="submit">Proceed<i class="fa fa-sign-in ml-1"></i></button>
                    </div>

                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>

<div class="modal fade right" id="centralModalSm" tabindex="-1" role="dialog" aria-hidden="true" action="logincode.php" method="post">
  <div class="modal-dialog modal-side modal-bottom-right" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"> Are you sure you want to log out?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">NO</button>
                <button type="submit" class="btn btn-primary" id="logout" >YES</button>
            </div>
        </div>
    </div>
</div>

 <div class="modal fade custom-scrollbar list-unstyled" id="clearanceModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog cascading-modal" role="document">
            <!--Content-->
            <div class="modal-content">
    
                <!--Header-->
                <div class="modal-header teal darken-1 white-text">
                                    <h5 class="title"><i class="fa fa-user-plus"></i> Barangay Clearance</h5>
                    <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <!--Body-->
                <div class="modal-body">
                <form method="POST" action="addstaff.php">
                    <div class="md-form form-sm">
                        <select class="mdb-select colorful-select dropdown-primary">
                        <option value="#">Select Purpose</option>
                        <option value="Building">Building</option>
                        	<option value="Fencing">Fencing</option>
                        	<option value="Electrical">Electrical</option>
                        	<option value="H2o Connection">H2o Connection</option>
                        	</select>
                        <label>Purpose</label>
                                  
                    </div>
                     <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form29" class="form-control" name="fullname">
                        <label for="form29">Fulname</label>
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-address-book prefix"></i>
                        <input type="text" id="form29" class="form-control" name="Address">
                        <label for="form29">Address</label>
                    
                    </div>
 					<div class="md-form form-sm">
                        <i class="fa fa-address-book prefix"></i>
                        <input type="text" id="form29" class="form-control" name="Address">
                        <label for="form29">Purpose Location</label>
                    </div>
                    
                     <div class="md-form form-sm">
                        
                        <input type="date" class="form-control" name="">
                        <label for="date-picker">Day</label>
                    </div>
                    <div class="md-form form-sm">
                       <select class="mdb-select colorful-select dropdown-primary">
                        <option value="#">Select Amount</option>
                        <option value="100">100</option>
                        	<option value="150">150</option>
                        	<option value="200">200</option>
                        	<option value="250">250</option>
                        	</select>                        <label for="form29">Amount</label>
                    </div>
                    
    
                </div>
                </form>
                <!--Footer-->
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-elegant waves-effect ml-auto" data-dismiss="modal">Close</button>
                    <div class="text-center mt-2">
                        <button class="btn btn-teal" type="submit" >Proceed<i class="fa fa-sign-in ml-1"></i></button>
                    </div>
                  </div>
            	</div>
            </div>
            </div>
            <!--/.Content-->
        </div>
    </div>


<div id="printArea">
    <img src="image/logo.jpg" style="width: 800px;">
    <h3 style="text-align:center;margin-top: 30px">CERTIFICATION</h3><br><br>
    
    </div>
    <div class="screen-output">
        <table id="printtable" class="table table-striped table-bordered" style="width: 800px;" >
              
            <tbody style="font-size: 15px">
                
                <tr ">
                    <div style="text-align: center;"> This is to certify that _________________________________ Filipino, _________________</div><br>
                    <div class="ml-5">years of age is a resident of Purok ______ of this Barangay. He/She is a resident
                  of good standing with no previous or <br> <br> pending case on file with us.</div><br><br>
                    <div style="text-align: center;">Issued this_______ day of_______ 2018 for the purpose:</div><br><br>
                    <div style="text-align: center;">_______________________________</div><br><br><br><br>
                    <div style="float: right; margin-right: 120px" > Hon. Kelvin Paul T. Unabia</div><br>
                    <div style="float: right; margin-right: 140px" >Punong Barangay</div>
                </tr>
             </tbody>
            </table>
    </div>
</div> 

<?php include 'footer.php';?>

