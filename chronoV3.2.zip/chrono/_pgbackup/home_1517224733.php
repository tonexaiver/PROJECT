<?php 
session_start();
if (!isset($_SESSION['username'])) {
	header("location: index.php");
}
$con = mysqli_connect('localhost','root','','dataneil');
$query = "select * from tableneil;";
$result = mysqli_query($con,$query);

?>

<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css">
	<style type="text/css">
		body{
			background-color: skyblue;

		}


		.card-header{
			background-color: gray; 
		}
		.card-body{
			background-color: ;

		}
		#btnSubmit, #btns{
			border-radius: 100px;	
			text-decoration: none
		}
		b{
			color:black;
		}
		.form-control{
			border-top: none;
			border-right: none;
			border-left: none;
		}
		.card-footer{
			background-color: transparent;
		}
		.tds{

		}


	</style>
</head>
<body>
	
	
		<div class="container">
			<div class="row">
				<div class="col-md-3"></div>
				<div class="col-md-6"><br>
						<div class="card">
							<div class="card-header"><center><h5></h5></center></div>
							<div class="card-body">
								<center>
									<form>
										<div class="table-responsive">
											<table class="table table-grey table-hover">
											
											<tr>
												<th>Id</th>
												<th>FullName</th>
												<th>Username</th>
												<th>password</th>
												<th>Action</th>
											</tr>
											<tr>
												<?php 
												while($row = mysqli_fetch_array($result))
												{
													echo "<tr>";
													echo "<td>".$row['id']."</td>";
													echo "<td>".$row['fullname']."</td>";
													echo "<td>".$row['username']."</td>";
													echo "<td>".$row['password']."</td>";
													echo "<td><a href='edit.php?id=".$row['id']."&action=edit'>EDIT</a>.<a href='delete.php?id=".$row['id']."&action=delete'>DELETE</a></td>";
													echo "</tr>";
												}
												

												?>
											</tr>
											<tr>
												<td class=".tds"><a href='register.php'>Add New</td>
												<td class=".tds"><a href="logout.php">logout</a></td>
													
											</tr>
											</table>
											</div>
									</form>

								</center>
							</div>
						</div>
				</div>
				<div class="col-md-3">
				</div>
			</div>
		</div>	
		

		
</body>
</html>