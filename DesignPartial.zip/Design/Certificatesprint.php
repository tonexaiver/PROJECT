<div class="heads">
<?php include 'header4staff.php'; ?>
</div>
<?php

$id=$_GET['id'];

$con=mysqli_connect('localhost','root','','fmsg9');

$query = "select * from tblcertification where id=".$id;

$result = mysqli_query($con, $query);

$row = mysqli_fetch_array($result);





?>
<style type="text/css">
    #btnprint2{
        float: right;
    }
 </style>
<main>
    <section>
        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                

                <div class="col-md-12">
                <form action="Certificatesform.php" class="form1" method="POST">
                    <div class="row">
                    <div class="col-md-12">
                        <div class="md-form ">
                            <input type="text" value = "<?php echo $row['Fullname']; ?>" name="fullname" id="fullname" class="form-control">
                            <label for="name" >Full name</label>
                        </div>
                    </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="md-form ">
                                <input type="text" name="age" value = "<?php echo $row['Age']; ?>" class="form-control">
                                <label>Age</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="md-form ">
                                <input type="text" name="purok" value = "<?php echo $row['Purok']; ?>" class="form-control">
                                <label>Porok</label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                    <div class="col-md-12">
                        <div class="md-form ">
                            <input type="text" name="day" value = "<?php echo $row['Day']; ?>" class="form-control">
                            <label for="name">Barangay</label>
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-md-12">
                        <div class="md-form ">
                            <input type="text" name="month" value = "<?php echo $row['Month']; ?>" class="form-control">
                            <label for="name">Month</label>
                        </div>
                    </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            
                        <div class="md-form ">
                            <input type="text" name="year" value = "<?php echo $row['Year']; ?>" class="form-control">
                            <label for="name">Year</label>
                        </div>
                    
                        </div>
                        <div class="col-md-6">
                            <div class="md-form ">
                            <input type="text" name="purpose" value = "<?php echo $row['Purpose']; ?>" class="form-control">
                            <label for="name">Barangay Address</label>
                        </div>
                        </div>
                        
                    </div>
                    
                    
                    <!-- <button type="button"  class="btn btn-purple" id="s" style="float: right" onclick="print()">
                        Print
                    </button> -->
                            <!-- Button trigger modal -->    

                    <button type="submit" name="submit" id="submit" class="btn btn-indigo" style="float: right">
                        Show Clearance<i class="fa fa-paper-plane-o ml-2"></i>
                    </button>
                    <a href="Certificateshow.php" id="btnprint2" style="color:white;"><button"  class="btn btn-orange">
                        Back<i class="fa fa-hand-pointer-o ml-2"></i>
                    </button></a>
                      
                    
                    
                    
                    </form>  
                </div>
                

                                                
            </div>
            <div class="col-md-3">
            </div>
        </div>
    </section>
</main>
<div class="foot">
    <?php include 'footer.php';?>
</div>
