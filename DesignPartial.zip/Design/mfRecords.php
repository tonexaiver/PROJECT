<?php
$con = mysqli_connect('localhost','root','','ADWEB');
$query = "SELECT * FROM STAFF;";
$result = mysqli_query($con,$query);
?>

<?php require 'header.php'; ?>
<<main>
    <section> <div class="container-fluid">
    <div class="row">

    <!-- Grid column -->
    <div class="col-md-4 mb-r">
        <form method="POST" action="addstaff.php">
        <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="hidden" id="form29" class="form-control" name="StaffID" value="<?php if(isset($id)) echo $id; ?>" >
                    </div>
                <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form29" class="form-control" name="lastname" value="<?php if(isset($lastname)) echo $lastname; ?>">
                        <label for="form29">Lastname</label>
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form30" class="form-control" name="firstname" value="<?php if(isset($firstname)) echo $firstname; ?>">
                        <label for="form30">Firstname</label>
                    </div>
                     <div class="md-form form-sm">
                        <i class="fa fa-address-book prefix"></i>
                        <input type="text" id="form31" class="form-control" name="address" value="<?php if(isset($address)) echo $address; ?>">
                        <label for="form31">Address</label>
                    </div>
                     <div class="md-form form-sm">
                        <i class="fa fa-calendar prefix"></i>
                        <input type="text" class="form-control datepicker" name="birthday" value="<?php if(isset($birthday)) echo $birthday; ?>">
                        <label for="date-picker">Birthday</label>
                                  
                    </div>
                     <div class="md-form form-sm">
                        <i class="fa fa-user prefix"></i>
                        <input type="text" id="form33" class="form-control" name="position" value="<?php if(isset($position)) echo $position; ?>">
                        <label for="form33">Position</label>
                    </div>
                    
    
                    <div class="text-center mt-2">
                   
                    <button class="btn btn-teal" type="submit" name="update">edit<i class="fa fa-sign-in ml-1"></i></button>
               
                    </div>
    
               </form>
       

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-md-8">

        <!--Panel-->
        <div class="card mb-3">
            <div class="card-body">
                <div class="media d-block d-md-flex mt-md-0 mt-4 mb-4">
                    <div class="media-body ml-md-12 ml-0">
                       <h5 class="my-2 h5 text-center">BARANGGAY STAFF</h5>

                     
                        <div class="table-responsive">
        <table id="table_id" class="mdl-data-table" width="100%" cellspacing="0">
            <thead>
            <tr>
                <th>Lastname</th>
                <th>Firstname</th>
                <th>Address</th>
                <th>Birthday</th>
                <th>Position</th>
            </tr>
            </thead>

            <tbody>
                <?php 
                while ($row = mysqli_fetch_array($result)) {
                    # code...
                    echo "<tr>";
                    echo "<td contenteditable>".$row['lastname']."</td>";
                    echo "<td contenteditable>".$row['firstname']."</td>";
                    echo "<td contenteditable>".$row['address']."</td>";
                    echo "<td contenteditable>".$row['birthday']."</td>";
                    echo "<td contenteditable>".$row['position']."</td>";
                     echo "<td><button class='form-control'><a href='Staffedit.php?id=".$row['StaffID']."&action=edit'>EDIT</a></button>||<button class='form-control'><a href='delete.php?id=".$row['StaffID']."&action=delete'>DELETE</a></button></td>";
                 echo "</tr>";
                }

                ?>
            </tbody>
        </table>
        </div>


                                   


                
                </div>
            </div>
            </div>
            </div>
        </div>
        <!--/.Panel-->

    </div>
    <!-- Grid column -->

</div>
<?php require 'footer.php'; ?>
