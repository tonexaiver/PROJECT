
<?php require 'header4admin.php';?>
<body>
    <!--Main layout-->
    <main>
         <div class="row">
             <div class="col-md-4"><a href="finaladminpanel.php" class="btn-floating btn-small blue animated fadeInDownBig" style="float: left" ripple-radius><i class="fa fa-backward"></i></a></div>
             <div class="col-md-4">
                 <form class="animated flipInY" method="POST" action="addusercode.php">
                    <p class="h4 text-center mb-4">ADD USER</p>

                    <!-- Material input email -->
                    <div class="md-form">
                        <i class="fa fa-user prefix grey-text"></i>
                        <input type="text" id="uname" class="form-control" name="username">
                        <label for="uname">Username</label>
                    </div>

                    <!-- Material input password -->
                    <div class="md-form">
                        <i class="fa fa-lock prefix grey-text"></i>
                        <input type="password" id="pass" class="form-control" name="password">
                        <label for="pass">Password</label>
                    </div>
                    <div class="md-form">
                        <i class="fa fa-lock prefix grey-text"></i>
                        <input type="password" id="conpas" class="form-control" name="conpass">
                        <label for="conpas">Confirm Password</label>
                    </div>
                    <div>
                        <div class="md-form ">
                            <i class="fa fa-users prefix grey-text"></i>
                        <select class="mdb-select ml-5" class="mdb-select colorful-select dropdown-primary ml-5" name="type">

                            <option value="" disabled selected>Choose your option</option>
                            <option value="Staff">Staff</option>
                            <option value="Admin">Admin</option>
                          >
                        </select>
                        <label style="color: #3f5c80">User Type</label>
                     </div>
                    </div>
                    <div class="md-form form-sm">
                        <i class="fa fa-calendar prefix"></i>
                        <input type="text" class="form-control datepicker" name="dateposted">
                        <label for="date-picker">Date</label>        
                    </div>
                    <div class="md-form">
                        <i class="fa fa-lock prefix grey-text"></i>
                        <input type="text" id="recpass" class="form-control" name="recoverpass">
                        <label for="recpass" >Recovery Password</label>
                        <p class="ml-5" style="color: red;"> Please don't forget your Recovery Password!!</p>
                    </div>

                    <div class="text-center mt-4">
                        <button class="btn btn-default" type="submit">SUBMIT</button>
                    </div>
                </form>
             </div>
             <div class="col-md-4"></div>
         </div>



                      
    </main>
    <!--Main layout-->
</body>
    

    
   
    

 <?php require 'footer.php';?>  
