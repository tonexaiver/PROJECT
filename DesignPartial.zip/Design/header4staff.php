
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="mdl/material.min.css">
    <link rel="stylesheet" type="text/css" href="dataTables/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/mdb/compiled.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/style1.css">

</head>
<style>
    .dropdown:hover .dropbtn {
    background-color: #3e8e41;
}
.dropdown:hover .dropdown-menu {
    display: block;
}

</style>


<body class="fixed-sn light-blue-skin">

    <!--Main Navigation-->
    <header>

        <!--Navbar-->
        <nav class="navbar navbar-expand-lg navbar-dark double-nav  fixed-top scrolling-navbar">

            <!-- SideNav slide-out button -->
            <div class="float-left">
                <a href="#" data-activates="slide-out" class="button-collapse">
                    <i class="fa fa-bars"></i>
                </a>
            </div>

            <!-- Breadcrumb-->
            <div class="breadcrumb-dn mr-auto">
                <p>Barangay Ward IV</p>
            </div>
            <p style="font-size: 25px; font-family: century gothic">STAFF</p>

            

        </nav>
        <!--/.Navbar-->

        <!-- Sidebar navigation -->
        <div id="slide-out" class="side-nav fixed sn-bg-4">
            <ul class="custom-scrollbar list-unstyled">
                <!-- Logo -->
                        <li style="height: 190px;">
                            
                                <a href="Finalstaffpanel.php"><img src="image/officiallogo.png" style="height: 200px ; width: 200px;" class="ml-3"></a>
                        </li>
                <!--/. Logo -->
                
                <hr>
                <!--/.Search Form-->
                <!-- Side navigation links -->
                <li>
                    <ul class="collapsible collapsible-accordion">
                      <li>
                          <a class="collapsible-header waves-effect arrow-r">
                              <i class="fa fa-user-circle"></i> ACCOUNT SETTINGS
                              <i class="fa fa-angle-down rotate-icon"></i>
                          </a>
                          <div class="collapsible-body">
                              <ul>
                                  <li>
                                      <a href="EditAccount4staff.php" class="waves-effect">EDIT</a>
                                  </li>
                                  <li>
                                      <a data-toggle="modal" data-target="#Logout" class="waves-effect">LOG OUT</a>
                                  </li>
                                  
                              </ul>
                          </div>

                             <li>
                      <a class="collapsible-header waves-effect arrow-r">
                          <i class="fa fa-rocket"></i> FEATURES
                          <i class="fa fa-angle-down rotate-icon"></i>
                      </a>
                      <div class="collapsible-body">
                          <ul>
                              <li>
                                  <a href="#" class="waves-effect">TANUD ATTENDANCE MONITORING</a>
                              </li>
                              <li>
                                  <a href="ClearancesUI.php" class="waves-effect">CERTIFICATE ISSUANCE</a>
                              </li>
                              <li>
                                  <a href="#" class="waves-effect">BLOTTER</a>
                              </li>
                          </ul>
                      </div>
                  </li>
                   <li>
                      <a class="collapsible-header waves-effect arrow-r">
                          <i class="fa fa-folder-open"></i> RECORDS
                          <i class="fa fa-angle-down rotate-icon"></i>
                      </a>
                      <div class="collapsible-body">
                          <ul>
                            
                              <li>
                                  <a href="#" class="waves-effect">RESIDENTS</a>
                              </li>
                              <li>
                                  <a href="#" class="waves-effect">BARANGAY TANUDS</a>
                              </li>
                              <li>
                                  <a href="#" class="waves-effect">SERVICE LOGS</a>
                              </li>
                              <li>
                                  <a href="#" class="waves-effect">TANUD ATTENDANCE</a>
                              </li>
                          </ul>
                      </div>
                  </li>
                  <li>
                      <a class="collapsible-header waves-effect arrow-r">
                          <i class="fa fa-plus-circle"></i> NEW
                          <i class="fa fa-angle-down rotate-icon"></i>
                      </a>
                      <div class="collapsible-body">
                          <ul>
                              
                              <li>
                                  <a href="addresidentUI.php" class="waves-effect">RESIDENT</a>
                              </li>
                              <li>
                                  <a href="#" class="waves-effect">BARANGAY TANUD</a>
                              </li>
                          </ul>
                      </div>
                  </li>
                  <li>
                      <a class="collapsible-header waves-effect arrow-r">
                          <i class="fa fa-file"></i> REPORT
                          <i class="fa fa-angle-down rotate-icon"></i>
                      </a>
                      <div class="collapsible-body">
                          <ul>
                              <li>
                                  <a href="#" class="waves-effect">PUROK SURVEY</a>
                              </li>
                              <li>
                                  <a href="#" class="waves-effect">GENERAL SURVEY</a>
                              </li>
                              <li>
                                  <a href="#" class="waves-effect">BADAC</a>
                              </li>
                              <li>
                                  <a href="#" class="waves-effect">BPOC</a>
                              </li>

                            
                          </ul>
                      </div>
                  </li>

            <!-- Mask -->
            <div class="sidenav-bg mask-strong"></div>

        </div>
        <!--/. Sidebar navigation -->

    </header>

<div class="modal fade custom-scrollbar list-unstyled" id="Logout" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog cascading-modal" role="document">
            <!--Content-->
            <div class="modal-content">
    
                <!--Body-->
                <div class="modal-body">
                    <p style="text-align: center; font-family: century gothic; font-size: 25px;">Are you sure you want to log out?</p>

                  <div class="row">
                      <div class="col-md-2 ml-4"></div>
                      <div class="col-md-3"> <div class="text-center mt-2">
                        <button class="btn btn-info" data-dismiss="modal" >No</button>
                    </div></div>
                      <div class="col-md-1"></div>
                      <div class="col-md-3"><div class="text-center mt-2">
                        <button class="btn btn-info"><a href="logini.php" style="color: white;">Yes</a></button>
                    </div></div>
                      <div class="col-md-3"></div>

                  </div>
                
                   
                    
    
                </div>
                </form>
                <!--Footer-->
                
            </div>
            <!--/.Content-->
        </div>
    </div>

 
 </body>
 </html>



