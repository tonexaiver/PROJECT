<?php 

$un=$_POST['un'];
$ps=$_POST['ps'];
$tl=$_POST['tl'];
	

		$con = mysqli_connect('localhost','root','','dataneil');

		$query = "INSERT INTO tableneil(username,password,timelog) VALUES ('$un','$ps','$tl');";

 ?>